"""Core application modules"""

