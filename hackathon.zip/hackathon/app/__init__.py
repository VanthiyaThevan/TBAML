"""
TBAML System - Trade-Based Anti-Money Laundering
UC1: Line of Business Verification
"""

__version__ = "0.1.0"

