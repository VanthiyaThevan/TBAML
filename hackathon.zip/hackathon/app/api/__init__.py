"""
API Module for TBAML System
REST API endpoints for UC1 and other services
"""
