# Trade-Based Anti-Money Laundering (TBAML) System
## UC1: Line of Business Verification

A hackathon project for detecting trade-based money laundering through automated Line of Business (LOB) verification using AI and public data sources.

---

## Project Overview

This system verifies the legitimacy and activity level of businesses involved in international trade by:

- Collecting data from multiple public sources
- Using AI to analyze business information
- Generating risk flags and alerts
- Providing explainable results with source citations

## Tech Stack

### Backend
- **Python 3.11+** with **FastAPI**
- **PostgreSQL** (SQLite for dev)
- **SQLAlchemy** ORM

### AI/ML
- **OpenAI GPT-4** / **Anthropic Claude** APIs
- **spaCy** for NLP
- **Hugging Face Transformers**

### Frontend
- **React 18+** with **TypeScript**
- **Material-UI** / **Tailwind CSS**

### Tools
- **Docker** for containerization
- **BeautifulSoup4** / **Scrapy** for web scraping

## Quick Start

### Prerequisites
- Python 3.11+
- PostgreSQL (or SQLite for development)
- Node.js 18+ (for frontend)

### Setup

1. **Clone repository**
```bash
git clone <repository-url>
cd hackathon
```

2. **Set up Python environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

3. **Configure environment variables**
```bash
cp .env.example .env
# Edit .env with your API keys and database credentials
```

4. **Run database migrations**
```bash
alembic upgrade head
```

5. **Start backend server**
```bash
uvicorn app.main:app --reload
```

6. **Start frontend** (in separate terminal)
```bash
cd frontend
npm install
npm start
```

## Project Structure

```
hackathon/
├── app/
│   ├── api/           # API endpoints
│   ├── models/        # Database models
│   ├── services/      # Business logic
│   ├── ai/            # AI/ML modules
│   ├── data/          # Data collection modules
│   └── main.py        # FastAPI app
├── frontend/          # React application
├── tests/             # Test files
├── docs/              # Documentation
└── requirements.txt   # Python dependencies
```

## API Endpoints

### UC1: Line of Business Verification

**POST** `/api/v1/lob/verify`

**Request:**
```json
{
  "client": "Company Name",
  "client_country": "Country Code",
  "client_role": "Import/Export",
  "product_name": "Product Description"
}
```

**Response:**
```json
{
  "ai_response": "...",
  "website_source": "https://...",
  "publication_date": "2024-01-01",
  "activity_level": "Active",
  "flags": ["Red Flag - No business"],
  "sources": [...]
}
```

## Development

See [PROJECT_PLAN.md](./PROJECT_PLAN.md) for detailed development stages and tasks.

## License

[Specify license]

## Contributors

[Team members]

