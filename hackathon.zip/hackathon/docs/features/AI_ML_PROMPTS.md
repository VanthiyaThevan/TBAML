# AI/ML Prompts Used in TBAML System

This document lists all prompts used in the AI/ML components of the Trade-Based Anti-Money Laundering (TBAML) system.

---

## Table of Contents

1. [System Prompts](#system-prompts)
2. [LOB Verification Prompt](#lob-verification-prompt)
3. [Activity Classification Prompt](#activity-classification-prompt)
4. [Risk Assessment Prompt](#risk-assessment-prompt)
5. [Structured Response Prompt](#structured-response-prompt)
6. [Prompt Usage Summary](#prompt-usage-summary)

---

## System Prompts

### Base System Prompt

**Location**: `app/ai/prompts.py` - `PromptTemplates.SYSTEM_PROMPT_BASE`

**Prompt**:
```
You are an expert analyst for Trade-Based Anti-Money Laundering (TBAML) compliance verification. 
Your role is to analyze company information and provide accurate, objective assessments of business legitimacy and activity levels.

Guidelines:
- Provide factual, evidence-based analysis
- Focus on verifiable information from provided sources
- Identify any compliance concerns or red flags
- Be objective and avoid speculation
- Cite specific evidence for your conclusions
```

**Used in**:
- All LLM calls (LOB Verification, Activity Classification, Risk Assessment)

---

## LOB Verification Prompt

**Location**: `app/ai/prompts.py` - `PromptTemplates.lob_verification_prompt()`

**Method**: `lob_verification_prompt(company_name, country, role, product, collected_data, website_text)`

**Full Prompt Template**:
```
Analyze the following company for Line of Business (LOB) verification:

COMPANY INFORMATION:
- Name: {company_name}
- Country: {country}
- Role: {role}
- Product: {product}

COLLECTED DATA:

WEBSITE CONTENT:
{website_text[:2000]}  # Limited to first 2000 characters

DATA SOURCES:
{len(sources)} source(s) were consulted:
  1. {source_name_1}
  2. {source_name_2}
  ... (up to 5 sources)

ANALYSIS REQUIRED:
Please provide a comprehensive analysis including:

1. BUSINESS LEGITIMACY ASSESSMENT:
   - Is this a legitimate business operation?
   - Is there evidence of actual business activity?
   - Are there any concerns about the business legitimacy?

2. ACTIVITY LEVEL CLASSIFICATION:
   - Classify as one of: Active, Dormant, Inactive, Suspended, Unknown
   - Provide reasoning for the classification

3. RISK INDICATORS:
   - Identify any compliance concerns
   - Flag any suspicious patterns
   - Note any data quality issues

4. CONFIDENCE LEVEL:
   - Rate your confidence in this assessment (High, Medium, Low)
   - Explain any limitations in the available data

Please provide your analysis in a clear, structured format.
```

**Input Parameters**:
- `company_name`: Company name to verify
- `country`: Country code (e.g., "US", "GB", "RU")
- `role`: "Import" or "Export"
- `product`: Product/service name (optional)
- `collected_data`: Dictionary with collected data from all sources
- `website_text`: Optional website content (truncated to 2000 chars)

**Used in**:
- `app/ai/orchestrator.py` - `_generate_ai_response()` method
- Main LOB verification analysis

**System Prompt Combined With**:
- Base system prompt: `PromptTemplates.SYSTEM_PROMPT_BASE`

---

## Activity Classification Prompt

**Location**: `app/ai/prompts.py` - `PromptTemplates.activity_classification_prompt()`

**Method**: `activity_classification_prompt(company_name, evidence_text)`

**Full Prompt Template**:
```
Classify the business activity level for: {company_name}

Based on the following evidence:
{evidence_text[:1500]}  # Limited to first 1500 characters

Classify the business as one of:
- Active: Business is currently operational with evidence of recent activity
- Dormant: Business exists but shows no recent activity
- Inactive: Business appears to be inactive or discontinued
- Suspended: Business operations are suspended
- Unknown: Insufficient data to determine status

Provide:
1. Classification (one of the above)
2. Confidence level (High/Medium/Low)
3. Key evidence supporting your classification
```

**Input Parameters**:
- `company_name`: Company name
- `evidence_text`: Evidence text (truncated to 1500 chars)

**Used in**:
- `app/ai/classifier.py` - `ActivityClassifier.classify_activity()` method
- Activity level classification step

**System Prompt Combined With**:
- Base system prompt + specialization:
```
{PROMPT_TEMPLATES.SYSTEM_PROMPT_BASE}

Focus on activity level classification based on evidence.
```

**Output Expected**:
- Activity level: "Active", "Dormant", "Inactive", "Suspended", or "Unknown"
- Confidence: "High", "Medium", or "Low"
- Reasoning: Explanation text

---

## Risk Assessment Prompt

**Location**: `app/ai/prompts.py` - `PromptTemplates.risk_assessment_prompt()`

**Method**: `risk_assessment_prompt(company_name, country, evidence_text, sanctions_info)`

**Full Prompt Template**:
```
Assess compliance and risk indicators for: {company_name} ({country})

EVIDENCE:
{evidence_text[:1500]}  # Limited to first 1500 characters

SANCTIONS INFORMATION:
{sanctions_info}  # Optional, only if sanctions match found

Identify:
1. Compliance issues (if any)
2. Risk indicators
3. Data quality concerns
4. Source reliability issues

Format your response with specific flags/categories.
```

**Input Parameters**:
- `company_name`: Company name
- `country`: Country code
- `evidence_text`: Evidence text (truncated to 1500 chars)
- `sanctions_info`: Optional sanctions information (if match found)

**Used in**:
- `app/ai/classifier.py` - `RiskClassifier.assess_risk()` method
- Risk assessment step

**System Prompt Combined With**:
- Base system prompt + specialization:
```
{PROMPT_TEMPLATES.SYSTEM_PROMPT_BASE}

Focus on risk and compliance assessment.
```

**Output Expected**:
- Risk score: Float between 0.0 and 1.0
- Risk level: "High", "Medium", or "Low"
- Flags: List of risk indicators
- Compliance issues: List of identified issues

---

## Structured Response Prompt

**Location**: `app/ai/prompts.py` - `PromptTemplates.generate_structured_response()`

**Method**: `generate_structured_response()` (static method)

**Prompt**:
```
Please provide your response in the following JSON format:

{
  "analysis": "Your detailed analysis text here",
  "activity_level": "Active|Dormant|Inactive|Suspended|Unknown",
  "confidence": "High|Medium|Low",
  "flags": ["flag1", "flag2"],
  "risk_score": 0.0-1.0,
  "evidence_cited": ["evidence1", "evidence2"]
}

Ensure the response is valid JSON.
```

**Status**: Currently defined but not actively used (responses are parsed from free-form text)

**Note**: This prompt template is available but the system currently relies on `ResponseParser` to extract structured data from free-form LLM responses.

---

## Prompt Usage Summary

### Flow in AI Orchestrator

1. **Main Analysis** (`_generate_ai_response()`):
   - **Prompt**: `LOB_VERIFICATION_PROMPT`
   - **System Prompt**: `SYSTEM_PROMPT_BASE`
   - **Purpose**: Generate comprehensive LOB verification analysis
   - **LLM Call**: Single call to Ollama

2. **Activity Classification** (`_classify_activity()`):
   - **Prompt**: `ACTIVITY_CLASSIFICATION_PROMPT`
   - **System Prompt**: `SYSTEM_PROMPT_BASE + "Focus on activity level classification based on evidence."`
   - **Purpose**: Classify business activity level
   - **LLM Call**: Single call to Ollama

3. **Risk Assessment** (`_assess_risk()`):
   - **Prompt**: `RISK_ASSESSMENT_PROMPT`
   - **System Prompt**: `SYSTEM_PROMPT_BASE + "Focus on risk and compliance assessment."`
   - **Purpose**: Assess compliance risks and generate risk score
   - **LLM Call**: Single call to Ollama

### Total LLM Calls Per Verification

**Per LOB Verification Request**:
- 3 LLM calls minimum:
  1. Main LOB verification analysis
  2. Activity classification
  3. Risk assessment

**Additional Calls** (if needed):
- Flag generation uses rule-based logic (no LLM calls)
- Response parsing uses regex/pattern matching (no LLM calls)

---

## Prompt Configuration

### LLM Settings

**Location**: `app/ai/config.py` - `AIConfig`

**Current Settings**:
- **Provider**: Ollama (local)
- **Model**: `llama3.2`
- **Base URL**: `http://localhost:11434`
- **Temperature**: `0.3` (low for consistency)
- **Max Tokens**: `2000`

**Temperature Rationale**:
- Low temperature (0.3) ensures consistent, factual responses
- Important for compliance/regulatory analysis where consistency matters

### Text Length Limits

- **Website Content**: Max 2000 characters (in LOB verification prompt)
- **Evidence Text**: Max 1500 characters (in activity/risk prompts)
- **Overall Evidence**: Max 4000 characters (prepared by `TextProcessor`)

**Rationale**:
- Limits token usage (cost/performance)
- Focuses LLM on most relevant information
- Prevents context window overflow

---

## Response Parsing

**Location**: `app/ai/prompts.py` - `ResponseParser`

The system uses a hybrid approach:
1. **Try JSON extraction**: If LLM returns JSON, parse directly
2. **Fallback to regex**: Extract key fields from free-form text

**Extracted Fields**:
- `activity_level`: "Active", "Dormant", "Inactive", "Suspended", "Unknown"
- `confidence`: "High", "Medium", "Low"
- `flags`: List of flag messages
- `analysis`: Full analysis text

**Patterns Used**:
- Activity level: `(?:Activity|Classification|Status).*?:\s*(Active|Dormant|Inactive|Suspended|Unknown)`
- Confidence: `(?:Confidence|Confidence Level).*?:\s*(High|Medium|Low)`
- Flags: `(?:Flag|Issue|Concern|Alert).*?:\s*([^\n]+)`

---

## Example Prompts (Real Usage)

### Example 1: Shell plc

**Input**:
- Company: "Shell plc"
- Country: "GB"
- Role: "Export"
- Product: "Oil & Gas"

**Generated Prompt** (LOB Verification):
```
Analyze the following company for Line of Business (LOB) verification:

COMPANY INFORMATION:
- Name: Shell plc
- Country: GB
- Role: Export
- Product: Oil & Gas

COLLECTED DATA:

WEBSITE CONTENT:
[First 2000 chars of Shell website content]

DATA SOURCES:
3 source(s) were consulted:
  1. web_scraper
  2. company_registry_fetcher
  3. sanctions_checker

ANALYSIS REQUIRED:
Please provide a comprehensive analysis including:

1. BUSINESS LEGITIMACY ASSESSMENT:
   - Is this a legitimate business operation?
   - Is there evidence of actual business activity?
   - Are there any concerns about the business legitimacy?

2. ACTIVITY LEVEL CLASSIFICATION:
   - Classify as one of: Active, Dormant, Inactive, Suspended, Unknown
   - Provide reasoning for the classification

3. RISK INDICATORS:
   - Identify any compliance concerns
   - Flag any suspicious patterns
   - Note any data quality issues

4. CONFIDENCE LEVEL:
   - Rate your confidence in this assessment (High, Medium, Low)
   - Explain any limitations in the available data

Please provide your analysis in a clear, structured format.
```

---

## Notes

1. **All prompts are dynamic**: Generated at runtime with actual data
2. **System prompts are combined**: Base system prompt + task-specific instruction
3. **Text truncation**: Long content is truncated to manage token usage
4. **No hardcoded examples**: Prompts are generated fresh for each request
5. **Error handling**: If LLM fails, system falls back to keyword-based extraction

---

## Future Improvements

1. **Structured JSON responses**: Encourage LLMs to return JSON for easier parsing
2. **Few-shot examples**: Add examples to prompts for better consistency
3. **Chain-of-thought**: Add reasoning steps for complex analysis
4. **Prompt versioning**: Track prompt versions for A/B testing
5. **Prompt optimization**: Fine-tune prompts based on response quality metrics

---

**Last Updated**: 2025-01-XX
**Version**: 1.0
