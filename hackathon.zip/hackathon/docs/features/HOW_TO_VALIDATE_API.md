# How to Validate the API is Working

## Method 1: Using the Test Script (Recommended)

### Step 1: Start the API Server
```bash
cd /Users/prabhugovindan/working/hackathon
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Step 2: Run the Test Script (in another terminal)
```bash
cd /Users/prabhugovindan/working/hackathon
source venv/bin/activate
python test_api.py
```

This will test all endpoints:
- Health check
- UC1 main endpoint
- Get verification
- List verifications
- Error handling
- Swagger documentation

---

## Method 2: Using Swagger UI (Browser)

### Step 1: Start the server
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Step 2: Open browser
Visit: **http://localhost:8000/docs**

You'll see an interactive API documentation where you can:
- See all endpoints
- Test endpoints directly in the browser
- View request/response schemas
- Try API calls with the "Try it out" button

---

## Method 3: Using cURL Commands

### Test Health Check
```bash
curl http://localhost:8000/health
```

Expected response:
```json
{"status":"healthy","version":"0.1.0","timestamp":"2025-11-01T..."}
```

### Test UC1 Endpoint
```bash
curl -X POST "http://localhost:8000/api/v1/lob/verify" \
  -H "Content-Type: application/json" \
  -d '{
    "client": "Shell plc",
    "client_country": "GB",
    "client_role": "Export",
    "product_name": "Oil & Gas"
  }'
```

### Test Get Verification
```bash
curl http://localhost:8000/api/v1/lob/1
```

### Test List Verifications
```bash
curl "http://localhost:8000/api/v1/lob?limit=5&offset=0"
```

---

## Method 4: Using Python Requests

```python
import requests

# Health check
response = requests.get("http://localhost:8000/health")
print(response.json())

# UC1 endpoint
data = {
    "client": "Shell plc",
    "client_country": "GB",
    "client_role": "Export",
    "product_name": "Oil & Gas"
}
response = requests.post("http://localhost:8000/api/v1/lob/verify", json=data)
print(response.json())
```

---

## Method 5: Using Browser (Simple GET Endpoints)

Just open these URLs in your browser:

- **Health Check**: http://localhost:8000/health
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **List Verifications**: http://localhost:8000/api/v1/lob?limit=5

---

## Quick Validation Checklist

- [ ] Server starts without errors
- [ ] Health endpoint returns 200 OK
- [ ] Swagger UI loads at /docs
- [ ] UC1 endpoint accepts POST requests
- [ ] UC1 endpoint returns UC1 outputs (AI Response, Activity Level, Flags, Sources)
- [ ] Get endpoint retrieves records by ID
- [ ] List endpoint returns paginated results
- [ ] Error handling works (422 for invalid input, 404 for not found)

---

## Expected Response from UC1 Endpoint

```json
{
  "id": 1,
  "ai_response": "Analysis text from Ollama...",
  "website_source": "https://www.shell.com",
  "publication_date": "2025-10-30",
  "activity_level": "Active",
  "flags": [
    "[MEDIUM] source_reliability: Limited number of data sources"
  ],
  "sources": ["web_scraper", "company_registry", "sanctions_checker"],
  "confidence_score": "High",
  "is_red_flag": false,
  "risk_score": 0.25,
  "risk_level": "Low",
  "created_at": "2025-11-01T...",
  "updated_at": "2025-11-01T..."
}
```

---

## Troubleshooting

### Connection Refused
- Make sure the server is running: `uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload`
- Check if port 8000 is already in use

### 500 Internal Server Error
- Check server logs for errors
- Make sure Ollama is running: `ollama serve`
- Check database connection

### 422 Validation Error
- Check request body matches the schema
- Country code must be 2 characters (e.g., "US", "GB")
- Role must be "Import" or "Export"

---

## Quick Start Command

```bash
# Terminal 1: Start server
cd /Users/prabhugovindan/working/hackathon
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2: Test API
cd /Users/prabhugovindan/working/hackathon
source venv/bin/activate
python test_api.py
```


