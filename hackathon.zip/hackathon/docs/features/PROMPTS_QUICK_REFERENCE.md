# AI/ML Prompts - Quick Reference

Quick reference list of all prompts used in the TBAML system.

---

## 1. System Prompt (Base)

```
You are an expert analyst for Trade-Based Anti-Money Laundering (TBAML) compliance verification. 
Your role is to analyze company information and provide accurate, objective assessments of business legitimacy and activity levels.

Guidelines:
- Provide factual, evidence-based analysis
- Focus on verifiable information from provided sources
- Identify any compliance concerns or red flags
- Be objective and avoid speculation
- Cite specific evidence for your conclusions
```

**Used in**: All LLM calls

---

## 2. LOB Verification Prompt

```
Analyze the following company for Line of Business (LOB) verification:

COMPANY INFORMATION:
- Name: {company_name}
- Country: {country}
- Role: {role}
- Product: {product}

COLLECTED DATA:

WEBSITE CONTENT:
{website_text[:2000]}

DATA SOURCES:
{len(sources)} source(s) were consulted:
  1. {source_name_1}
  2. {source_name_2}
  ...

ANALYSIS REQUIRED:
Please provide a comprehensive analysis including:

1. BUSINESS LEGITIMACY ASSESSMENT:
   - Is this a legitimate business operation?
   - Is there evidence of actual business activity?
   - Are there any concerns about the business legitimacy?

2. ACTIVITY LEVEL CLASSIFICATION:
   - Classify as one of: Active, Dormant, Inactive, Suspended, Unknown
   - Provide reasoning for the classification

3. RISK INDICATORS:
   - Identify any compliance concerns
   - Flag any suspicious patterns
   - Note any data quality issues

4. CONFIDENCE LEVEL:
   - Rate your confidence in this assessment (High, Medium, Low)
   - Explain any limitations in the available data

Please provide your analysis in a clear, structured format.
```

**Purpose**: Main LOB verification analysis  
**Location**: `app/ai/orchestrator.py` → `_generate_ai_response()`

---

## 3. Activity Classification Prompt

```
Classify the business activity level for: {company_name}

Based on the following evidence:
{evidence_text[:1500]}

Classify the business as one of:
- Active: Business is currently operational with evidence of recent activity
- Dormant: Business exists but shows no recent activity
- Inactive: Business appears to be inactive or discontinued
- Suspended: Business operations are suspended
- Unknown: Insufficient data to determine status

Provide:
1. Classification (one of the above)
2. Confidence level (High/Medium/Low)
3. Key evidence supporting your classification
```

**Purpose**: Classify business activity level  
**Location**: `app/ai/classifier.py` → `ActivityClassifier.classify_activity()`

**System Prompt**: Base + "Focus on activity level classification based on evidence."

---

## 4. Risk Assessment Prompt

```
Assess compliance and risk indicators for: {company_name} ({country})

EVIDENCE:
{evidence_text[:1500]}

SANCTIONS INFORMATION:
{sanctions_info}  # Optional, only if sanctions match found

Identify:
1. Compliance issues (if any)
2. Risk indicators
3. Data quality concerns
4. Source reliability issues

Format your response with specific flags/categories.
```

**Purpose**: Assess compliance risks and generate risk score  
**Location**: `app/ai/classifier.py` → `RiskClassifier.assess_risk()`

**System Prompt**: Base + "Focus on risk and compliance assessment."

---

## 5. Structured Response Prompt (Not Currently Used)

```
Please provide your response in the following JSON format:

{
  "analysis": "Your detailed analysis text here",
  "activity_level": "Active|Dormant|Inactive|Suspended|Unknown",
  "confidence": "High|Medium|Low",
  "flags": ["flag1", "flag2"],
  "risk_score": 0.0-1.0,
  "evidence_cited": ["evidence1", "evidence2"]
}

Ensure the response is valid JSON.
```

**Status**: Defined but not actively used (system uses free-form text parsing)

---

## Prompt Flow Summary

```
User Request
    ↓
1. LOB Verification Prompt → Main Analysis
    ↓
2. Activity Classification Prompt → Activity Level
    ↓
3. Risk Assessment Prompt → Risk Score & Flags
    ↓
Flag Generation (Rule-based, no LLM)
    ↓
Response Formatting
```

**Total LLM Calls**: 3 per verification request

---

## Configuration

- **Provider**: Ollama (local)
- **Model**: llama3.2
- **Temperature**: 0.3
- **Max Tokens**: 2000
- **Text Limits**: 
  - Website: 2000 chars
  - Evidence: 1500 chars
  - Overall: 4000 chars

---

## Response Parsing

**Method**: Hybrid (JSON extraction + regex fallback)

**Extracts**:
- `activity_level`: Active/Dormant/Inactive/Suspended/Unknown
- `confidence`: High/Medium/Low
- `flags`: List of flag messages
- `analysis`: Full analysis text

---

**See**: `AI_ML_PROMPTS.md` for detailed documentation
