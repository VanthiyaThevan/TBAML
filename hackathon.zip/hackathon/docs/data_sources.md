# Data Sources for LOB Verification

## Overview

This document lists and documents all public data sources available for Line of Business (LOB) verification in the TBAML system.

## Data Source Categories

### 1. Company Registry Databases

#### A. Public Company Registries (by Country)
- **USA**: SEC EDGAR Database
  - URL: https://www.sec.gov/edgar/searchedgar/companysearch.html
  - Type: Government database
  - Data Available: Company filings, annual reports, ownership
  - Access: Free, public
  - Rate Limit: Reasonable use policy

- **UK**: Companies House
  - URL: https://find-and-update.company-information.service.gov.uk/
  - Type: Government database
  - Data Available: Company information, filings, directors
  - Access: Free, public API available
  - Rate Limit: API rate limits apply

- **Australia**: ASIC (Australian Securities and Investments Commission)
  - URL: https://asic.gov.au/
  - Type: Government database
  - Data Available: Company registrations, business names
  - Access: Free search, paid for detailed records

#### B. International Company Directories
- **OpenCorporates**: https://opencorporates.com/
  - Type: Commercial API
  - Data Available: Global company data from 140+ jurisdictions
  - Access: API available (free tier available)
  - Rate Limit: Varies by plan

### 2. Sanctions and Watchlists

#### A. OFAC Sanctions Lists (USA)
- **OFAC SDN List**: https://ofac.treasury.gov/specially-designated-nationals-list-sdn-list
  - Type: Government database
  - Data Available: Sanctioned entities and individuals
  - Access: Free, downloadable files
  - Update Frequency: Regular updates

#### B. UN Sanctions
- **UN Security Council**: https://www.un.org/securitycouncil/sanctions/information
  - Type: Government/International
  - Data Available: UN sanctions listings
  - Access: Free, public
  - Update Frequency: Regular updates

#### C. EU Sanctions
- **EU Sanctions Map**: https://www.sanctionsmap.eu/
  - Type: Government database
  - Data Available: EU sanctions information
  - Access: Free, public

#### D. PEP (Politically Exposed Persons) Lists
- **World-Check** (Commercial)
- **Dow Jones Risk & Compliance** (Commercial)
- Note: Some PEP lists require commercial licenses

### 3. Web Intelligence Sources

#### A. Company Websites
- Direct website scraping
- Company information pages
- About us pages
- Contact information
- Product/service descriptions

#### B. Business Directories
- **Yellow Pages**: Business listings
- **LinkedIn Company Pages**: Company information
- **Crunchbase**: Startup and company data
- **Bloomberg**: Company profiles (requires subscription)

#### C. News and Media
- Google News searches
- Industry publications
- Press releases
- News articles mentioning the company

### 4. Trade and Shipping Databases

#### A. Import/Export Records (Public)
- **USA**: Import/Export trade data (limited public access)
- Some countries publish trade statistics (aggregated)
- Shipping manifests (if publicly available)

#### B. Industry-Specific Directories
- Industry association member lists
- Trade organization directories
- Sector-specific registries

## Recommended Implementation Priority

### Phase 1 (Immediate)
1. Company website scraping (direct access)
2. Google News search (via API or scraping)
3. Basic company registry checks (public APIs)
4. OFAC sanctions list check

### Phase 2 (Enhanced)
1. OpenCorporates API integration
2. UN/EU sanctions lists
3. LinkedIn company data (if API available)
4. Industry directory searches

### Phase 3 (Advanced)
1. Commercial watchlist services
2. Detailed trade records
3. Advanced company intelligence services

## Data Collection Considerations

### Rate Limiting
- Respect website robots.txt
- Implement delays between requests
- Use API rate limits where applicable
- Cache responses when appropriate

### Data Quality
- Verify data from multiple sources
- Track data source and freshness
- Handle missing or incomplete data
- Validate data format and consistency

### Legal and Ethical
- Comply with terms of service
- Respect copyright and privacy
- Use public data only
- Document data source attribution

### Privacy and Compliance
- Don't collect unnecessary PII
- Store data securely
- Implement data retention policies
- Comply with GDPR if handling EU data

## Data Source Reliability

| Source | Reliability | Freshness | Cost | Ease of Access |
|--------|------------|-----------|------|----------------|
| Company Websites | High | High | Free | Easy |
| Government Registries | Very High | Medium | Free | Medium |
| Sanctions Lists | Very High | High | Free | Easy |
| News Sources | Medium | Very High | Free | Medium |
| Commercial APIs | High | High | Paid | Easy |

## Implementation Notes

- Start with free, easily accessible sources
- Build modular connectors for each source
- Implement caching to reduce redundant requests
- Track source attribution for audit purposes
- Log all data collection activities

