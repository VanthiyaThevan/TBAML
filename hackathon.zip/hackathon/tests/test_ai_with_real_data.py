"""
Test Stage 3 AI/ML with Real Company Data from Database
Tests AI analysis on actual collected company data
"""

from app.ai.orchestrator import AIOrchestrator
from app.models.base import get_session_factory
from app.models.lob import LOBVerification
from app.core.logging import get_logger
from typing import List, Dict, Any

logger = get_logger(__name__)


def test_ai_with_real_companies(limit: int = 3):
    """
    Test AI analysis on real companies from database
    
    Args:
        limit: Number of companies to analyze
    """
    print("=" * 80)
    print("TESTING AI/ML WITH REAL COMPANY DATA")
    print("=" * 80)
    print()
    
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        # Get companies that haven't been analyzed yet (no AI response)
        verifications = db.query(LOBVerification).filter(
            LOBVerification.ai_response.is_(None)
        ).limit(limit).all()
        
        if not verifications:
            print("No companies found without AI analysis.")
            print("Testing with companies that have data...")
            verifications = db.query(LOBVerification).filter(
                LOBVerification.website_source.isnot(None)
            ).limit(limit).all()
        
        print(f"Found {len(verifications)} companies to analyze\n")
        
        orchestrator = AIOrchestrator()
        
        results = []
        
        for i, v in enumerate(verifications, 1):
            print("=" * 80)
            print(f"ANALYZING COMPANY #{i}: {v.client} ({v.client_country})")
            print("=" * 80)
            print()
            
            # Prepare input data
            input_data = {
                "client": v.client,
                "client_country": v.client_country,
                "client_role": v.client_role,
                "product_name": v.product_name
            }
            
            # Prepare collected data from sources
            sources_list = v.sources if isinstance(v.sources, list) else [v.sources] if v.sources else []
            
            collected_data = {
                "sources": sources_list,
                "data": {
                    "website_content": f"Website: {v.website_source}" if v.website_source else None,
                    "description": f"{v.client} is a company in {v.client_country}"
                }
            }
            
            # Prepare aggregated data
            aggregated_data = {
                "data": {
                    "url": v.website_source,
                    "description": f"{v.client} ({v.client_country}) - {v.product_name}"
                },
                "sources": [s.get("name") if isinstance(s, dict) else str(s) for s in sources_list] if sources_list else []
            }
            
            print(f"Company: {v.client}")
            print(f"Country: {v.client_country}")
            print(f"Role: {v.client_role}")
            print(f"Product: {v.product_name}")
            print(f"Website: {v.website_source or 'Not found'}")
            print(f"Sources: {len(sources_list)}")
            print()
            print("Running AI analysis...")
            print()
            
            # Run AI analysis
            try:
                result = orchestrator.analyze_lob(
                    input_data=input_data,
                    collected_data=collected_data,
                    aggregated_data=aggregated_data
                )
                
                print("✅ Analysis Complete!")
                print()
                print("Results:")
                print(f"  Activity Level: {result.get('activity_level')}")
                print(f"  Risk Level: {result.get('risk_level')} (score: {result.get('risk_score', 0):.2f})")
                print(f"  Confidence: {result.get('confidence_score')}")
                print(f"  Red Flag: {result.get('is_red_flag')}")
                print(f"  Flags Generated: {len(result.get('flags', []))}")
                
                if result.get('flags'):
                    print("  Flags:")
                    for flag in result.get('flags', [])[:3]:  # Show first 3
                        print(f"    - {flag}")
                
                print()
                print("AI Response Preview:")
                ai_response = result.get('ai_response', '')
                if ai_response:
                    print(f"  {ai_response[:300]}..." if len(ai_response) > 300 else f"  {ai_response}")
                else:
                    print("  (No AI response generated)")
                
                print()
                
                results.append({
                    "verification_id": v.id,
                    "company": v.client,
                    "result": result
                })
                
            except Exception as e:
                print(f"❌ Error analyzing {v.client}: {str(e)}")
                import traceback
                traceback.print_exc()
                print()
        
        print("=" * 80)
        print("SUMMARY")
        print("=" * 80)
        print(f"Companies analyzed: {len(results)}/{len(verifications)}")
        print()
        
        if results:
            print("Analysis Results:")
            for r in results:
                print(f"  {r['company']}: {r['result'].get('activity_level')} ({r['result'].get('risk_level')})")
        
        print("=" * 80)
        print()
        print("✅ AI analysis complete! Results ready for database integration.")
        print()
        
        return results
        
    finally:
        db.close()


def analyze_all_companies():
    """Analyze all companies in database"""
    print("=" * 80)
    print("ANALYZING ALL COMPANIES")
    print("=" * 80)
    print()
    
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        total = db.query(LOBVerification).count()
        print(f"Total companies in database: {total}")
        print("This may take a while...")
        print()
        
        # Analyze in batches
        limit = 5  # Process 5 at a time
        offset = 0
        
        while True:
            verifications = db.query(LOBVerification).offset(offset).limit(limit).all()
            if not verifications:
                break
            
            print(f"Processing batch: {offset+1} to {offset+len(verifications)}")
            # Would call AI analysis here
            
            offset += limit
            if offset >= total:
                break
        
        print("All companies processed!")
        
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--all":
        analyze_all_companies()
    else:
        limit = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 3
        test_ai_with_real_companies(limit=limit)

