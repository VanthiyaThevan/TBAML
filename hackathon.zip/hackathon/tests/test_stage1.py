"""
Stage 1 Testing Script
Tests all Stage 1 components
"""

import sys
from fastapi.testclient import TestClient

def test_logging():
    """Test logging system"""
    print("Testing logging system...")
    from app.core.logging import get_logger
    logger = get_logger("test")
    logger.info("Test log message", component="logging")
    print("  ✓ Logging system working")

def test_models():
    """Test database models"""
    print("Testing database models...")
    from app.models.lob import LOBVerification
    from app.models.base import Base
    print(f"  ✓ Models imported: {LOBVerification.__tablename__}")

def test_database():
    """Test database initialization and connection"""
    print("Testing database...")
    from app.models.base import init_db, get_session_factory
    from app.models.lob import LOBVerification
    
    # Initialize database
    init_db()
    print("  ✓ Database initialized")
    
    # Test connection
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    try:
        count = db.query(LOBVerification).count()
        print(f"  ✓ Database connection works (Records: {count})")
    finally:
        db.close()

def test_api():
    """Test FastAPI application"""
    print("Testing FastAPI application...")
    from app.main import app
    
    client = TestClient(app)
    
    # Test root endpoint
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "TBAML System"
    print(f"  ✓ Root endpoint: {data}")
    
    # Test health endpoint
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"
    print(f"  ✓ Health endpoint: {response.json()}")
    
    # Test docs endpoint exists
    response = client.get("/docs")
    assert response.status_code == 200
    print("  ✓ API documentation accessible")

def main():
    """Run all Stage 1 tests"""
    print("=" * 60)
    print("Stage 1 Testing - TBAML System")
    print("=" * 60)
    print()
    
    try:
        test_logging()
        print()
        test_models()
        print()
        test_database()
        print()
        test_api()
        print()
        print("=" * 60)
        print("✅ All Stage 1 tests passed!")
        print("=" * 60)
        return 0
    except Exception as e:
        print()
        print("=" * 60)
        print(f"❌ Test failed: {e}")
        print("=" * 60)
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())

