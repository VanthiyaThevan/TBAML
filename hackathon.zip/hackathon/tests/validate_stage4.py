"""
Validate Stage 4: API & Backend Development
Step-by-step validation of all API components
"""

import sys
import json
from typing import Dict, Any
from fastapi.testclient import TestClient
from app.core.logging import get_logger
from app.main import app
from app.api.schemas import (
    LOBVerificationInput,
    LOBVerificationOutput,
    ErrorResponse,
    HealthResponse
)
from app.api.routes import router
from app.models.base import get_session_factory
from app.models.lob import LOBVerification

logger = get_logger(__name__)


class Stage4Validator:
    """Validates Stage 4 API & Backend components"""
    
    def __init__(self):
        """Initialize validator"""
        self.client = TestClient(app)
        self.results = {
            "passed": [],
            "failed": [],
            "warnings": []
        }
    
    def validate_all(self) -> Dict[str, Any]:
        """Run all validations"""
        print("=" * 80)
        print("STAGE 4: API & BACKEND DEVELOPMENT - VALIDATION")
        print("=" * 80)
        print()
        
        # Test 1: API Structure
        self.validate_api_structure()
        
        # Test 2: Schemas
        self.validate_schemas()
        
        # Test 3: Health Check Endpoint
        self.validate_health_endpoint()
        
        # Test 4: UC1 Main Endpoint
        self.validate_uc1_endpoint()
        
        # Test 5: Get Verification Endpoint
        self.validate_get_endpoint()
        
        # Test 6: List Verifications Endpoint
        self.validate_list_endpoint()
        
        # Test 7: Error Handling
        self.validate_error_handling()
        
        # Test 8: Response Formatting
        self.validate_response_formatting()
        
        # Test 9: Source Citation
        self.validate_source_citation()
        
        # Test 10: OpenAPI Documentation
        self.validate_openapi_docs()
        
        # Test 11: Database Service Layer
        self.validate_database_service()
        
        # Test 12: Request Logging
        self.validate_request_logging()
        
        # Print summary
        self.print_summary()
        
        return self.results
    
    def validate_api_structure(self):
        """Validate API endpoint structure"""
        print("=" * 80)
        print("VALIDATION 1: API Endpoint Structure")
        print("=" * 80)
        
        try:
            # Check if routes are registered
            routes = [route.path for route in app.routes]
            
            expected_routes = [
                "/",
                "/health",
                "/api/v1/lob/verify",
                "/docs",
                "/openapi.json"
            ]
            
            print(f"✅ FastAPI app initialized")
            print(f"   Total routes: {len(routes)}")
            
            # Check for key routes
            found_routes = []
            for route in expected_routes:
                if any(route in r for r in routes):
                    found_routes.append(route)
                    print(f"   ✅ {route}")
                else:
                    print(f"   ❌ {route} - NOT FOUND")
            
            if len(found_routes) == len(expected_routes):
                self.results["passed"].append("API Structure")
            else:
                self.results["failed"].append(f"API Structure: Missing routes")
            
        except Exception as e:
            print(f"❌ API structure validation failed: {str(e)}")
            self.results["failed"].append(f"API Structure: {str(e)}")
        
        print()
    
    def validate_schemas(self):
        """Validate API schemas"""
        print("=" * 80)
        print("VALIDATION 2: API Schemas (Pydantic Models)")
        print("=" * 80)
        
        try:
            # Test LOBVerificationInput
            input_data = {
                "client": "Test Company",
                "client_country": "US",
                "client_role": "Export",
                "product_name": "Oil & Gas"
            }
            
            input_schema = LOBVerificationInput(**input_data)
            assert input_schema.client == "Test Company"
            assert input_schema.client_country == "US"
            print("✅ LOBVerificationInput schema working")
            
            # Test validation
            try:
                invalid = LOBVerificationInput(
                    client="",  # Empty should fail
                    client_country="US",
                    client_role="Export",
                    product_name="Test"
                )
                print("⚠️  Input validation didn't catch empty client")
                self.results["warnings"].append("Input validation: Empty client not caught")
            except Exception:
                print("✅ Input validation working (rejects empty client)")
            
            # Test invalid country code
            try:
                invalid = LOBVerificationInput(
                    client="Test",
                    client_country="USA",  # Should be 2 chars
                    client_role="Export",
                    product_name="Test"
                )
                print("⚠️  Country validation didn't catch invalid length")
                self.results["warnings"].append("Country validation: Invalid length not caught")
            except Exception:
                print("✅ Country validation working (rejects invalid length)")
            
            # Test invalid role
            try:
                invalid = LOBVerificationInput(
                    client="Test",
                    client_country="US",
                    client_role="Invalid",  # Should be Import/Export
                    product_name="Test"
                )
                print("⚠️  Role validation didn't catch invalid role")
                self.results["warnings"].append("Role validation: Invalid role not caught")
            except Exception:
                print("✅ Role validation working (rejects invalid role)")
            
            self.results["passed"].append("API Schemas")
            
        except Exception as e:
            print(f"❌ Schema validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"API Schemas: {str(e)}")
        
        print()
    
    def validate_health_endpoint(self):
        """Validate health check endpoint"""
        print("=" * 80)
        print("VALIDATION 3: Health Check Endpoint")
        print("=" * 80)
        
        try:
            response = self.client.get("/health")
            
            assert response.status_code == 200, f"Expected 200, got {response.status_code}"
            
            data = response.json()
            assert "status" in data, "Missing 'status' in response"
            
            print(f"✅ Health check endpoint working")
            print(f"   Status: {data.get('status')}")
            print(f"   Response: {data}")
            
            self.results["passed"].append("Health Check Endpoint")
            
        except Exception as e:
            print(f"❌ Health check validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Health Check: {str(e)}")
        
        print()
    
    def validate_uc1_endpoint(self):
        """Validate UC1 main endpoint"""
        print("=" * 80)
        print("VALIDATION 4: UC1 Main Endpoint (/api/v1/lob/verify)")
        print("=" * 80)
        
        try:
            # Test with valid input
            test_data = {
                "client": "Shell plc",
                "client_country": "GB",
                "client_role": "Export",
                "product_name": "Oil & Gas"
            }
            
            print("Testing POST /api/v1/lob/verify...")
            response = self.client.post("/api/v1/lob/verify", json=test_data)
            
            if response.status_code == 200:
                data = response.json()
                
                # Check required UC1 outputs
                assert "ai_response" in data, "Missing ai_response in response"
                assert "activity_level" in data, "Missing activity_level in response"
                assert "flags" in data, "Missing flags in response"
                assert "sources" in data, "Missing sources in response"
                
                print(f"✅ UC1 endpoint working")
                print(f"   Status: {response.status_code}")
                print(f"   Activity Level: {data.get('activity_level')}")
                print(f"   Flags: {len(data.get('flags', []))}")
                print(f"   Sources: {len(data.get('sources', []))}")
                
                if data.get('ai_response'):
                    print(f"   AI Response: {len(data['ai_response'])} chars")
                
                self.results["passed"].append("UC1 Main Endpoint")
            else:
                print(f"⚠️  Unexpected status code: {response.status_code}")
                print(f"   Response: {response.text[:200]}")
                self.results["warnings"].append(f"UC1 Endpoint: Status {response.status_code}")
            
        except Exception as e:
            print(f"❌ UC1 endpoint validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"UC1 Endpoint: {str(e)}")
        
        print()
    
    def validate_get_endpoint(self):
        """Validate get verification endpoint"""
        print("=" * 80)
        print("VALIDATION 5: Get Verification Endpoint")
        print("=" * 80)
        
        try:
            # Get a record ID from database
            SessionLocal, _ = get_session_factory()
            db = SessionLocal()
            
            try:
                verification = db.query(LOBVerification).first()
                
                if verification:
                    verification_id = verification.id
                    
                    response = self.client.get(f"/api/v1/lob/{verification_id}")
                    
                    if response.status_code == 200:
                        data = response.json()
                        assert "id" in data, "Missing id in response"
                        assert data["id"] == verification_id, "ID mismatch"
                        
                        print(f"✅ Get endpoint working")
                        print(f"   Retrieved ID: {data['id']}")
                        print(f"   Company: {data.get('client')}")
                        self.results["passed"].append("Get Verification Endpoint")
                    else:
                        print(f"⚠️  Get endpoint returned {response.status_code}")
                        self.results["warnings"].append(f"Get Endpoint: Status {response.status_code}")
                else:
                    print("⚠️  No records in database to test")
                    self.results["warnings"].append("Get Endpoint: No records to test")
            
            finally:
                db.close()
            
        except Exception as e:
            print(f"❌ Get endpoint validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Get Endpoint: {str(e)}")
        
        print()
    
    def validate_list_endpoint(self):
        """Validate list verifications endpoint"""
        print("=" * 80)
        print("VALIDATION 6: List Verifications Endpoint")
        print("=" * 80)
        
        try:
            response = self.client.get("/api/v1/lob?limit=5")
            
            if response.status_code == 200:
                data = response.json()
                assert isinstance(data, list), "Response should be a list"
                
                print(f"✅ List endpoint working")
                print(f"   Records returned: {len(data)}")
                
                if data:
                    print(f"   First record ID: {data[0].get('id')}")
                    print(f"   First company: {data[0].get('client')}")
                
                self.results["passed"].append("List Verifications Endpoint")
            else:
                print(f"⚠️  List endpoint returned {response.status_code}")
                self.results["warnings"].append(f"List Endpoint: Status {response.status_code}")
            
        except Exception as e:
            print(f"❌ List endpoint validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"List Endpoint: {str(e)}")
        
        print()
    
    def validate_error_handling(self):
        """Validate error handling"""
        print("=" * 80)
        print("VALIDATION 7: Error Handling")
        print("=" * 80)
        
        try:
            # Test invalid input
            invalid_data = {
                "client": "",
                "client_country": "USA",  # Invalid length
                "client_role": "Invalid",  # Invalid role
                "product_name": ""
            }
            
            response = self.client.post("/api/v1/lob/verify", json=invalid_data)
            
            if response.status_code in [400, 422]:
                print(f"✅ Error handling working (invalid input rejected)")
                print(f"   Status: {response.status_code}")
                self.results["passed"].append("Error Handling")
            else:
                print(f"⚠️  Unexpected status for invalid input: {response.status_code}")
                self.results["warnings"].append(f"Error Handling: Status {response.status_code}")
            
            # Test non-existent ID
            response = self.client.get("/api/v1/lob/99999")
            
            if response.status_code == 404:
                print(f"✅ 404 handling working (non-existent ID)")
            else:
                print(f"⚠️  Unexpected status for non-existent ID: {response.status_code}")
            
        except Exception as e:
            print(f"❌ Error handling validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Error Handling: {str(e)}")
        
        print()
    
    def validate_response_formatting(self):
        """Validate response formatting"""
        print("=" * 80)
        print("VALIDATION 8: Response Formatting (UC1 Output Schema)")
        print("=" * 80)
        
        try:
            test_data = {
                "client": "Test Company API",
                "client_country": "US",
                "client_role": "Export",
                "product_name": "Test Product"
            }
            
            response = self.client.post("/api/v1/lob/verify", json=test_data)
            
            if response.status_code == 200:
                data = response.json()
                
                # Check all UC1 output fields
                required_fields = [
                    "ai_response",
                    "activity_level",
                    "flags",
                    "sources"
                ]
                
                missing_fields = [field for field in required_fields if field not in data]
                
                if not missing_fields:
                    print(f"✅ Response formatting complete")
                    print(f"   All UC1 output fields present: {required_fields}")
                    
                    # Validate types
                    assert isinstance(data.get("flags"), list), "Flags should be a list"
                    assert isinstance(data.get("sources"), list), "Sources should be a list"
                    assert isinstance(data.get("activity_level"), str), "Activity level should be a string"
                    
                    print(f"   Field types validated")
                    self.results["passed"].append("Response Formatting")
                else:
                    print(f"⚠️  Missing fields: {missing_fields}")
                    self.results["warnings"].append(f"Response Formatting: Missing {missing_fields}")
            
        except Exception as e:
            print(f"❌ Response formatting validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Response Formatting: {str(e)}")
        
        print()
    
    def validate_source_citation(self):
        """Validate source citation in responses"""
        print("=" * 80)
        print("VALIDATION 9: Source Citation")
        print("=" * 80)
        
        try:
            test_data = {
                "client": "Test Source Citation",
                "client_country": "US",
                "client_role": "Export",
                "product_name": "Test"
            }
            
            response = self.client.post("/api/v1/lob/verify", json=test_data)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("sources"):
                    sources = data["sources"]
                    assert isinstance(sources, list), "Sources should be a list"
                    assert len(sources) > 0, "Should have at least one source"
                    
                    print(f"✅ Source citation working")
                    print(f"   Sources: {len(sources)}")
                    print(f"   Source names: {sources}")
                    self.results["passed"].append("Source Citation")
                else:
                    print(f"⚠️  No sources in response")
                    self.results["warnings"].append("Source Citation: No sources returned")
            
        except Exception as e:
            print(f"❌ Source citation validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Source Citation: {str(e)}")
        
        print()
    
    def validate_openapi_docs(self):
        """Validate OpenAPI documentation"""
        print("=" * 80)
        print("VALIDATION 10: OpenAPI/Swagger Documentation")
        print("=" * 80)
        
        try:
            # Test OpenAPI JSON
            response = self.client.get("/openapi.json")
            
            if response.status_code == 200:
                openapi = response.json()
                assert "openapi" in openapi, "Missing openapi version"
                assert "info" in openapi, "Missing info"
                assert "paths" in openapi, "Missing paths"
                
                print(f"✅ OpenAPI documentation available")
                print(f"   Version: {openapi.get('info', {}).get('version')}")
                print(f"   Title: {openapi.get('info', {}).get('title')}")
                print(f"   Paths: {len(openapi.get('paths', {}))}")
                
                # Check if UC1 endpoint is documented
                if "/api/v1/lob/verify" in openapi.get("paths", {}):
                    print(f"   ✅ UC1 endpoint documented")
                
                self.results["passed"].append("OpenAPI Documentation")
            else:
                print(f"⚠️  OpenAPI endpoint returned {response.status_code}")
                self.results["warnings"].append(f"OpenAPI Docs: Status {response.status_code}")
            
            # Test Swagger UI
            response = self.client.get("/docs")
            if response.status_code == 200:
                print(f"✅ Swagger UI available at /docs")
            else:
                print(f"⚠️  Swagger UI returned {response.status_code}")
            
        except Exception as e:
            print(f"❌ OpenAPI documentation validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"OpenAPI Docs: {str(e)}")
        
        print()
    
    def validate_database_service(self):
        """Validate database service layer"""
        print("=" * 80)
        print("VALIDATION 11: Database Service Layer (CRUD Operations)")
        print("=" * 80)
        
        try:
            from app.services.ai_service import AIService
            
            ai_service = AIService()
            print("✅ AIService initialized")
            
            # Check status method
            status = ai_service.get_analysis_status()
            assert status is not None
            assert "total_records" in status
            print(f"✅ Status method working")
            print(f"   Total Records: {status['total_records']}")
            
            # Check database operations work
            SessionLocal, _ = get_session_factory()
            db = SessionLocal()
            
            try:
                count = db.query(LOBVerification).count()
                print(f"✅ Database query working")
                print(f"   Records in DB: {count}")
                
                # Check CRUD operations exist
                from app.data.storage import DataStorage
                storage = DataStorage()
                print(f"✅ DataStorage service available")
                
                self.results["passed"].append("Database Service Layer")
            
            finally:
                db.close()
            
        except Exception as e:
            print(f"❌ Database service validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Database Service: {str(e)}")
        
        print()
    
    def validate_request_logging(self):
        """Validate request logging"""
        print("=" * 80)
        print("VALIDATION 12: Request Logging and Audit Trail")
        print("=" * 80)
        
        try:
            # Check if logging is configured
            from app.core.logging import get_logger
            
            logger = get_logger(__name__)
            print("✅ Logging system initialized")
            
            # Make a test request and check if it's logged
            test_data = {
                "client": "Test Logging",
                "client_country": "US",
                "client_role": "Export",
                "product_name": "Test"
            }
            
            response = self.client.post("/api/v1/lob/verify", json=test_data)
            
            # Logging should be happening (check if logger is working)
            logger.info("Test log message for validation")
            print(f"✅ Logging system functional")
            
            # Check if structured logging is configured
            import structlog
            print(f"✅ Structured logging configured (structlog)")
            
            self.results["passed"].append("Request Logging")
            
        except Exception as e:
            print(f"❌ Request logging validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Request Logging: {str(e)}")
        
        print()
    
    def print_summary(self):
        """Print validation summary"""
        print("=" * 80)
        print("VALIDATION SUMMARY")
        print("=" * 80)
        print()
        
        total_tests = len(self.results["passed"]) + len(self.results["failed"])
        passed = len(self.results["passed"])
        failed = len(self.results["failed"])
        warnings = len(self.results["warnings"])
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed}")
        print(f"❌ Failed: {failed}")
        print(f"⚠️  Warnings: {warnings}")
        print()
        
        if self.results["passed"]:
            print("✅ Passed Tests:")
            for test in self.results["passed"]:
                print(f"   - {test}")
            print()
        
        if self.results["failed"]:
            print("❌ Failed Tests:")
            for test in self.results["failed"]:
                print(f"   - {test}")
            print()
        
        if self.results["warnings"]:
            print("⚠️  Warnings:")
            for warning in self.results["warnings"]:
                print(f"   - {warning}")
            print()
        
        # Overall status
        if failed == 0:
            if warnings == 0:
                print("🎉 Stage 4: ALL VALIDATIONS PASSED!")
            else:
                print("✅ Stage 4: VALIDATIONS PASSED (with warnings)")
        else:
            print(f"⚠️  Stage 4: {failed} VALIDATION(S) FAILED")
        
        print("=" * 80)


if __name__ == "__main__":
    validator = Stage4Validator()
    results = validator.validate_all()
    
    # Exit with appropriate code
    if len(results["failed"]) > 0:
        sys.exit(1)
    else:
        sys.exit(0)


