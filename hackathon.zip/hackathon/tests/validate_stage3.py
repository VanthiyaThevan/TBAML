"""
Validate Stage 3: AI/ML Model Development
Step-by-step validation of all AI components
"""

import sys
from typing import Dict, Any
from app.core.logging import get_logger
from app.ai.config import AIConfig
from app.ai.text_processor import TextProcessor
from app.ai.llm_client import LLMClient
from app.ai.classifier import ActivityClassifier, RiskClassifier
from app.ai.flag_generator import FlagGenerator
from app.ai.orchestrator import AIOrchestrator
from app.ai.prompts import PromptTemplates, ResponseParser

logger = get_logger(__name__)


class Stage3Validator:
    """Validates Stage 3 AI/ML components"""
    
    def __init__(self):
        """Initialize validator"""
        self.config = AIConfig()
        self.results = {
            "passed": [],
            "failed": [],
            "warnings": []
        }
    
    def validate_all(self) -> Dict[str, Any]:
        """Run all validations"""
        print("=" * 80)
        print("STAGE 3: AI/ML MODEL DEVELOPMENT - VALIDATION")
        print("=" * 80)
        print()
        
        # Test 1: Configuration
        self.validate_config()
        
        # Test 2: Text Processor
        self.validate_text_processor()
        
        # Test 3: LLM Client
        self.validate_llm_client()
        
        # Test 4: Prompt Templates
        self.validate_prompts()
        
        # Test 5: Response Parser
        self.validate_response_parser()
        
        # Test 6: Activity Classifier
        self.validate_activity_classifier()
        
        # Test 7: Risk Classifier
        self.validate_risk_classifier()
        
        # Test 8: Flag Generator
        self.validate_flag_generator()
        
        # Test 9: AI Orchestrator
        self.validate_orchestrator()
        
        # Test 10: Integration Test
        self.validate_integration()
        
        # Print summary
        self.print_summary()
        
        return self.results
    
    def validate_config(self):
        """Validate AI configuration"""
        print("=" * 80)
        print("VALIDATION 1: AI Configuration")
        print("=" * 80)
        
        try:
            # Check config loads
            assert self.config is not None, "Config is None"
            print("✅ Config loaded successfully")
            
            # Check LLM provider (should be ollama only)
            assert self.config.llm_provider == "ollama", "LLM provider must be ollama"
            print(f"✅ LLM Provider: {self.config.llm_provider}")
            
            # Check activity classes
            assert len(self.config.activity_classes) > 0, "No activity classes defined"
            print(f"✅ Activity Classes: {self.config.activity_classes}")
            
            # Check thresholds
            assert 0 <= self.config.risk_threshold_medium <= 1, "Invalid risk threshold"
            assert 0 <= self.config.risk_threshold_high <= 1, "Invalid risk threshold"
            print(f"✅ Risk Thresholds: Medium={self.config.risk_threshold_medium}, High={self.config.risk_threshold_high}")
            
            # Check Ollama settings
            print(f"✅ Ollama Base URL: {self.config.ollama_base_url}")
            print(f"✅ Ollama Model: {self.config.ollama_model}")
            
            self.results["passed"].append("Configuration")
            
        except Exception as e:
            print(f"❌ Config validation failed: {str(e)}")
            self.results["failed"].append(f"Configuration: {str(e)}")
        
        print()
    
    def validate_text_processor(self):
        """Validate text processor"""
        print("=" * 80)
        print("VALIDATION 2: Text Processor")
        print("=" * 80)
        
        try:
            processor = TextProcessor(self.config)
            print("✅ TextProcessor initialized")
            
            # Test feature extraction
            test_text = """
            Vitol Group is a major international energy trading company based in the Netherlands.
            The company trades crude oil, refined products, natural gas, and other energy commodities.
            Founded in 1966, Vitol has operations in 40 countries and handles approximately 8 million
            barrels of crude oil and products per day.
            """
            
            features = processor.extract_features(test_text)
            
            assert features is not None, "Features extraction returned None"
            assert "word_count" in features, "Missing word_count in features"
            assert "has_company_mention" in features, "Missing has_company_mention in features"
            assert features["word_count"] > 0, "Word count should be > 0"
            assert features["text_quality_score"] >= 0, "Quality score should be >= 0"
            
            print(f"✅ Feature extraction working")
            print(f"   Word count: {features['word_count']}")
            print(f"   Quality score: {features['text_quality_score']:.2f}")
            print(f"   Entities found: {len(features['extracted_entities'])}")
            
            # Test text preparation
            prepared = processor.prepare_text_for_llm(test_text, max_length=100)
            assert len(prepared) <= 100, "Text preparation should respect max length"
            print(f"✅ Text preparation working (max length respected)")
            
            self.results["passed"].append("Text Processor")
            
        except Exception as e:
            print(f"❌ Text processor validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Text Processor: {str(e)}")
        
        print()
    
    def validate_llm_client(self):
        """Validate LLM client"""
        print("=" * 80)
        print("VALIDATION 3: LLM Client")
        print("=" * 80)
        
        try:
            llm_client = LLMClient(self.config)
            print(f"✅ LLMClient initialized (provider: ollama)")
            
            # Ollama doesn't need API key, but check if service is accessible
            print(f"✅ Using Ollama (local LLM)")
            print(f"   Base URL: {llm_client.config.ollama_base_url}")
            print(f"   Model: {llm_client.config.ollama_model}")
            
            # Try a simple call
            try:
                response = llm_client.generate_response(
                    prompt="Say 'hello' in one word.",
                    system_prompt="You are a helpful assistant."
                )
                
                if response.get("error"):
                    print(f"⚠️  Ollama call returned error: {response['error']}")
                    self.results["warnings"].append(f"LLM Client (Ollama): {response['error']}")
                elif response.get("content"):
                    print(f"✅ Ollama call successful")
                    print(f"   Response preview: {response['content'][:50]}...")
                    print(f"   Tokens used: {response.get('metadata', {}).get('tokens_used', 'N/A')}")
                    print(f"   Model: {response.get('metadata', {}).get('model', 'N/A')}")
                else:
                    print("⚠️  Ollama call returned no content")
                    self.results["warnings"].append("LLM Client (Ollama): No content in response")
            
            except Exception as e:
                print(f"⚠️  Ollama call failed: {str(e)}")
                self.results["warnings"].append(f"LLM Client (Ollama): {str(e)}")
            
            self.results["passed"].append("LLM Client (initialization)")
            
        except Exception as e:
            print(f"❌ LLM client validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"LLM Client: {str(e)}")
        
        print()
    
    def validate_prompts(self):
        """Validate prompt templates"""
        print("=" * 80)
        print("VALIDATION 4: Prompt Templates")
        print("=" * 80)
        
        try:
            # Test LOB verification prompt
            prompt = PromptTemplates.lob_verification_prompt(
                company_name="Shell plc",
                country="GB",
                role="Export",
                product="Oil & Gas",
                collected_data={"sources": [{"name": "web_scraper"}]},
                website_text="Shell is a major energy company."
            )
            
            assert prompt is not None, "Prompt is None"
            assert len(prompt) > 0, "Prompt is empty"
            assert "Shell plc" in prompt, "Company name not in prompt"
            assert "GB" in prompt, "Country not in prompt"
            assert "Export" in prompt, "Role not in prompt"
            
            print("✅ LOB verification prompt generated")
            
            # Test activity classification prompt
            activity_prompt = PromptTemplates.activity_classification_prompt(
                company_name="Shell plc",
                evidence_text="Shell operates in 70+ countries."
            )
            
            assert activity_prompt is not None, "Activity prompt is None"
            assert "Shell plc" in activity_prompt, "Company name not in activity prompt"
            assert "Active" in activity_prompt or "Dormant" in activity_prompt, "Activity classes not in prompt"
            
            print("✅ Activity classification prompt generated")
            
            # Test risk assessment prompt
            risk_prompt = PromptTemplates.risk_assessment_prompt(
                company_name="Shell plc",
                country="GB",
                evidence_text="Shell is a legitimate company."
            )
            
            assert risk_prompt is not None, "Risk prompt is None"
            assert "Shell plc" in risk_prompt, "Company name not in risk prompt"
            
            print("✅ Risk assessment prompt generated")
            
            # Test system prompt
            system_prompt = PromptTemplates.SYSTEM_PROMPT_BASE
            assert system_prompt is not None and len(system_prompt) > 0, "System prompt is empty"
            print("✅ System prompt available")
            
            self.results["passed"].append("Prompt Templates")
            
        except Exception as e:
            print(f"❌ Prompt templates validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Prompt Templates: {str(e)}")
        
        print()
    
    def validate_response_parser(self):
        """Validate response parser"""
        print("=" * 80)
        print("VALIDATION 5: Response Parser")
        print("=" * 80)
        
        try:
            parser = ResponseParser()
            
            # Test JSON response parsing
            json_response = """
            {
              "analysis": "Shell plc is a legitimate British multinational oil and gas company.",
              "activity_level": "Active",
              "confidence": "High",
              "flags": ["Limited data sources"],
              "risk_score": 0.25
            }
            """
            
            parsed = parser.parse_lob_response(json_response)
            
            assert parsed is not None, "Parsed response is None"
            assert "analysis" in parsed, "Missing analysis in parsed response"
            assert "activity_level" in parsed, "Missing activity_level in parsed response"
            
            print("✅ JSON response parsing working")
            print(f"   Activity Level: {parsed.get('activity_level')}")
            print(f"   Confidence: {parsed.get('confidence')}")
            
            # Test text response parsing (fallback)
            text_response = """
            Activity Level: Active
            Confidence: High
            Flags: Limited data sources, Need more verification
            """
            
            parsed_text = parser.parse_lob_response(text_response)
            
            assert parsed_text is not None, "Parsed text response is None"
            assert "activity_level" in parsed_text or parsed_text.get("analysis"), "Missing content in parsed text"
            
            print("✅ Text response parsing (fallback) working")
            
            self.results["passed"].append("Response Parser")
            
        except Exception as e:
            print(f"❌ Response parser validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Response Parser: {str(e)}")
        
        print()
    
    def validate_activity_classifier(self):
        """Validate activity classifier"""
        print("=" * 80)
        print("VALIDATION 6: Activity Classifier")
        print("=" * 80)
        
        try:
            classifier = ActivityClassifier(self.config)
            print("✅ ActivityClassifier initialized")
            
            test_text = """
            Shell plc is a British multinational oil and gas company headquartered in London.
            The company operates in over 70 countries and employs around 93,000 people.
            Recent reports show continued operations and business activity across all major markets.
            """
            
            result = classifier.classify(
                company_name="Shell plc",
                evidence_text=test_text
            )
            
            assert result is not None, "Classification result is None"
            assert "activity_level" in result, "Missing activity_level in result"
            assert result["activity_level"] in self.config.activity_classes + ["Unknown"], "Invalid activity level"
            assert "confidence" in result, "Missing confidence in result"
            
            print(f"✅ Activity classification working")
            print(f"   Activity Level: {result['activity_level']}")
            print(f"   Confidence: {result['confidence']}")
            
            if result.get("error"):
                print(f"⚠️  Classification had error: {result['error']}")
                self.results["warnings"].append(f"Activity Classifier: {result['error']}")
            
            self.results["passed"].append("Activity Classifier")
            
        except Exception as e:
            print(f"❌ Activity classifier validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Activity Classifier: {str(e)}")
        
        print()
    
    def validate_risk_classifier(self):
        """Validate risk classifier"""
        print("=" * 80)
        print("VALIDATION 7: Risk Classifier")
        print("=" * 80)
        
        try:
            classifier = RiskClassifier(self.config)
            print("✅ RiskClassifier initialized")
            
            test_text = """
            Shell plc is a legitimate British multinational oil and gas company.
            The company is registered and operates legally in multiple countries.
            No sanctions or compliance issues identified.
            """
            
            result = classifier.assess_risk(
                company_name="Shell plc",
                country="GB",
                evidence_text=test_text
            )
            
            assert result is not None, "Risk assessment result is None"
            assert "risk_score" in result, "Missing risk_score in result"
            assert "risk_level" in result, "Missing risk_level in result"
            assert 0 <= result["risk_score"] <= 1, "Risk score should be between 0 and 1"
            assert result["risk_level"] in ["High", "Medium", "Low"], "Invalid risk level"
            
            print(f"✅ Risk assessment working")
            print(f"   Risk Score: {result['risk_score']:.2f}")
            print(f"   Risk Level: {result['risk_level']}")
            print(f"   Flags: {len(result.get('flags', []))}")
            
            if result.get("error"):
                print(f"⚠️  Risk assessment had error: {result['error']}")
                self.results["warnings"].append(f"Risk Classifier: {result['error']}")
            
            self.results["passed"].append("Risk Classifier")
            
        except Exception as e:
            print(f"❌ Risk classifier validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Risk Classifier: {str(e)}")
        
        print()
    
    def validate_flag_generator(self):
        """Validate flag generator"""
        print("=" * 80)
        print("VALIDATION 8: Flag Generator")
        print("=" * 80)
        
        try:
            flag_generator = FlagGenerator(self.config)
            print("✅ FlagGenerator initialized")
            
            test_text = """
            The company has limited online presence and no verifiable registration information.
            Address information could not be confirmed through standard business registries.
            """
            
            flags = flag_generator.generate_flags(
                company_name="Test Company",
                country="US",
                evidence_text=test_text
            )
            
            assert flags is not None, "Flags result is None"
            assert isinstance(flags, list), "Flags should be a list"
            
            if flags:
                for flag in flags[:3]:  # Check first 3
                    assert "category" in flag, "Flag missing category"
                    assert "severity" in flag, "Flag missing severity"
                    assert "message" in flag, "Flag missing message"
            
            print(f"✅ Flag generation working")
            print(f"   Flags generated: {len(flags)}")
            
            if flags:
                print("   Sample flags:")
                for flag in flags[:3]:
                    print(f"     - [{flag['severity'].upper()}] {flag['category']}: {flag['message']}")
            
            # Test formatting
            formatted = flag_generator.format_flags_for_storage(flags)
            assert isinstance(formatted, list), "Formatted flags should be a list"
            print(f"✅ Flag formatting working ({len(formatted)} formatted flags)")
            
            self.results["passed"].append("Flag Generator")
            
        except Exception as e:
            print(f"❌ Flag generator validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Flag Generator: {str(e)}")
        
        print()
    
    def validate_orchestrator(self):
        """Validate AI orchestrator"""
        print("=" * 80)
        print("VALIDATION 9: AI Orchestrator")
        print("=" * 80)
        
        try:
            orchestrator = AIOrchestrator(self.config)
            print("✅ AIOrchestrator initialized")
            
            input_data = {
                "client": "Shell plc",
                "client_country": "GB",
                "client_role": "Export",
                "product_name": "Oil & Gas"
            }
            
            collected_data = {
                "sources": [
                    {"name": "web_scraper", "content": "Shell is a major energy company."},
                    {"name": "company_registry", "content": "Registered in UK."}
                ],
                "data": {
                    "website_content": "Shell operates in 70+ countries.",
                    "description": "British multinational oil and gas company"
                }
            }
            
            aggregated_data = {
                "data": {
                    "url": "https://www.shell.com",
                    "description": "Shell plc (GB) - Oil & Gas"
                },
                "sources": ["web_scraper", "company_registry"]
            }
            
            result = orchestrator.analyze_lob(
                input_data=input_data,
                collected_data=collected_data,
                aggregated_data=aggregated_data
            )
            
            assert result is not None, "Orchestrator result is None"
            assert "ai_response" in result, "Missing ai_response in result"
            assert "activity_level" in result, "Missing activity_level in result"
            assert "flags" in result, "Missing flags in result"
            assert "confidence_score" in result, "Missing confidence_score in result"
            assert "is_red_flag" in result, "Missing is_red_flag in result"
            
            print("✅ Complete LOB analysis working")
            print(f"   Activity Level: {result['activity_level']}")
            print(f"   Risk Level: {result.get('risk_level', 'N/A')}")
            print(f"   Confidence: {result['confidence_score']}")
            print(f"   Red Flag: {result['is_red_flag']}")
            print(f"   Flags: {len(result.get('flags', []))}")
            
            if result.get("error"):
                print(f"⚠️  Orchestration had error: {result['error']}")
                self.results["warnings"].append(f"AI Orchestrator: {result['error']}")
            
            self.results["passed"].append("AI Orchestrator")
            
        except Exception as e:
            print(f"❌ AI orchestrator validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"AI Orchestrator: {str(e)}")
        
        print()
    
    def validate_integration(self):
        """Validate integration with data storage"""
        print("=" * 80)
        print("VALIDATION 10: Integration with Data Storage")
        print("=" * 80)
        
        try:
            from app.services.ai_service import AIService
            
            ai_service = AIService()
            print("✅ AIService initialized")
            
            # Check status
            status = ai_service.get_analysis_status()
            
            assert status is not None, "Status is None"
            assert "total_records" in status, "Missing total_records in status"
            assert "with_ai_response" in status, "Missing with_ai_response in status"
            
            print("✅ Database integration working")
            print(f"   Total Records: {status['total_records']}")
            print(f"   With AI Response: {status['with_ai_response']}")
            print(f"   Completion: {status.get('completion_percentage', 0):.1f}%")
            
            self.results["passed"].append("Integration with Data Storage")
            
        except Exception as e:
            print(f"❌ Integration validation failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.results["failed"].append(f"Integration: {str(e)}")
        
        print()
    
    def print_summary(self):
        """Print validation summary"""
        print("=" * 80)
        print("VALIDATION SUMMARY")
        print("=" * 80)
        print()
        
        total_tests = len(self.results["passed"]) + len(self.results["failed"])
        passed = len(self.results["passed"])
        failed = len(self.results["failed"])
        warnings = len(self.results["warnings"])
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed}")
        print(f"❌ Failed: {failed}")
        print(f"⚠️  Warnings: {warnings}")
        print()
        
        if self.results["passed"]:
            print("✅ Passed Tests:")
            for test in self.results["passed"]:
                print(f"   - {test}")
            print()
        
        if self.results["failed"]:
            print("❌ Failed Tests:")
            for test in self.results["failed"]:
                print(f"   - {test}")
            print()
        
        if self.results["warnings"]:
            print("⚠️  Warnings:")
            for warning in self.results["warnings"]:
                print(f"   - {warning}")
            print()
        
        # Overall status
        if failed == 0:
            if warnings == 0:
                print("🎉 Stage 3: ALL VALIDATIONS PASSED!")
            else:
                print("✅ Stage 3: VALIDATIONS PASSED (with warnings)")
        else:
            print(f"⚠️  Stage 3: {failed} VALIDATION(S) FAILED")
        
        print("=" * 80)


if __name__ == "__main__":
    validator = Stage3Validator()
    results = validator.validate_all()
    
    # Exit with appropriate code
    if len(results["failed"]) > 0:
        sys.exit(1)
    else:
        sys.exit(0)

