"""
Stage 2 Testing Script
Tests all Stage 2 Data Collection & Integration components
"""

import sys
from datetime import datetime


def test_web_scraper():
    """Test web scraper"""
    print("Testing web scraper...")
    try:
        from app.data.scraper import WebScraper
        
        scraper = WebScraper(name="test_scraper", rate_limit=10)
        print(f"  ✓ WebScraper initialized: {scraper.name}")
        
        # Test rate limiting check
        scraper._rate_limit_check()
        print("  ✓ Rate limiting check works")
        
        # Test validation (with empty data)
        is_valid = scraper.validate_data({"sources": []})
        print(f"  ✓ Validation logic works: {is_valid == False}")
        
        print("  ✅ Web scraper tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Web scraper test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_company_registry():
    """Test company registry fetcher"""
    print("Testing company registry fetcher...")
    try:
        from app.data.company_registry import CompanyRegistryFetcher
        
        fetcher = CompanyRegistryFetcher(name="test_registry", rate_limit=5)
        print(f"  ✓ CompanyRegistryFetcher initialized: {fetcher.name}")
        
        # Test with sample query
        query = {
            "client": "Test Company Inc",
            "client_country": "US"
        }
        result = fetcher.fetch_data(query)
        print(f"  ✓ Fetched data: {len(result.get('sources', []))} sources")
        
        is_valid = fetcher.validate_data(result)
        print(f"  ✓ Data validation works: {is_valid}")
        
        print("  ✅ Company registry tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Company registry test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_sanctions_checker():
    """Test sanctions checker"""
    print("Testing sanctions checker...")
    try:
        from app.data.sanctions_checker import SanctionsChecker
        
        checker = SanctionsChecker(name="test_sanctions", rate_limit=10)
        print(f"  ✓ SanctionsChecker initialized: {checker.name}")
        
        # Test with sample query
        query = {
            "client": "Test Entity",
            "client_country": "US"
        }
        result = checker.fetch_data(query)
        print(f"  ✓ Checked sanctions: {len(result.get('sanctions_checks', {}))} lists")
        print(f"  ✓ Is sanctioned: {result.get('is_sanctioned', False)}")
        
        is_valid = checker.validate_data(result)
        print(f"  ✓ Data validation works: {is_valid}")
        
        print("  ✅ Sanctions checker tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Sanctions checker test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_data_validator():
    """Test data validator"""
    print("Testing data validator...")
    try:
        from app.data.validator import DataValidator
        
        validator = DataValidator()
        print("  ✓ DataValidator initialized")
        
        # Test validation with sample data
        sample_data = {
            "sources": [{
                "url": "https://example.com",
                "title": "Test Title",
                "content": "Test content here"
            }]
        }
        
        cleaned = validator.validate_and_clean(sample_data, "web_scraper")
        print(f"  ✓ Data cleaned: valid={cleaned.get('valid')}")
        print(f"  ✓ Errors: {len(cleaned.get('errors', []))}")
        print(f"  ✓ Warnings: {len(cleaned.get('warnings', []))}")
        
        # Test text cleaning
        clean_text = validator._clean_text("  Test   Text  ", max_length=10)
        print(f"  ✓ Text cleaning works: '{clean_text}'")
        
        # Test URL cleaning
        clean_url = validator._clean_url("https://example.com")
        print(f"  ✓ URL cleaning works: {clean_url}")
        
        print("  ✅ Data validator tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Data validator test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_data_storage():
    """Test data storage"""
    print("Testing data storage...")
    try:
        from app.data.storage import DataStorage
        from app.models.base import init_db
        
        # Initialize database
        init_db()
        print("  ✓ Database initialized")
        
        storage = DataStorage()
        print("  ✓ DataStorage initialized")
        
        # Test storing verification
        input_data = {
            "client": "Test Company",
            "client_country": "US",
            "client_role": "Export",
            "product_name": "Test Product"
        }
        
        collected_data = {
            "sources": ["web_scraper", "registry"]
        }
        
        aggregated_data = {
            "sources": ["web_scraper", "registry"],
            "data": {
                "url": "https://example.com",
                "company_name": "Test Company"
            }
        }
        
        verification_id = storage.store_verification(
            input_data, collected_data, aggregated_data
        )
        
        if verification_id:
            print(f"  ✓ Verification stored: ID={verification_id}")
            
            # Test retrieving verification
            verification = storage.get_verification(verification_id)
            if verification:
                print(f"  ✓ Verification retrieved: client={verification['client']}")
            
            # Test updating verification
            updated = storage.update_verification(
                verification_id,
                {"activity_level": "Active"}
            )
            print(f"  ✓ Verification updated: {updated}")
            
            # Test source tracking
            tracked = storage.track_data_source(
                verification_id,
                "test_source",
                "https://example.com/source"
            )
            print(f"  ✓ Source tracked: {tracked}")
        else:
            print("  ⚠ Could not store verification (database may need migration)")
        
        print("  ✅ Data storage tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Data storage test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_error_handling():
    """Test error handling and retry logic"""
    print("Testing error handling...")
    try:
        from app.data.error_handling import (
            RetryConfig,
            retry_with_backoff,
            ErrorHandler,
            safe_execute
        )
        
        # Test RetryConfig
        config = RetryConfig(max_retries=2, initial_delay=0.1)
        print(f"  ✓ RetryConfig created: max_retries={config.max_retries}")
        
        # Test safe_execute with successful function
        def success_func():
            return "success"
        
        result = safe_execute(success_func, default_return="failed")
        print(f"  ✓ Safe execute (success): {result}")
        
        # Test safe_execute with failing function
        def fail_func():
            raise ValueError("Test error")
        
        result = safe_execute(fail_func, default_return="failed")
        print(f"  ✓ Safe execute (failure): {result}")
        
        # Test ErrorHandler
        handler = ErrorHandler()
        error_info = handler.handle_error(
            ValueError("Test error"),
            "test_source",
            {"context": "test"}
        )
        print(f"  ✓ Error handled: {error_info['error_type']}")
        
        summary = handler.get_error_summary()
        print(f"  ✓ Error summary: {summary['total_errors']} errors")
        
        print("  ✅ Error handling tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Error handling test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_freshness_tracker():
    """Test freshness tracking"""
    print("Testing freshness tracker...")
    try:
        from app.data.freshness import DataFreshnessTracker
        
        tracker = DataFreshnessTracker()
        print("  ✓ DataFreshnessTracker initialized")
        
        # Test freshness score calculation
        collected_at = datetime.utcnow()
        score = tracker.calculate_freshness_score(collected_at)
        print(f"  ✓ Freshness score (now): {score}")
        
        # Test with older data
        old_time = datetime.utcnow() - timedelta(days=10)
        score = tracker.calculate_freshness_score(old_time)
        print(f"  ✓ Freshness score (10 days old): {score}")
        
        # Test data collection tracking
        tracking_info = tracker.track_data_collection(
            "test_source",
            collected_at,
            {"metadata": "test"}
        )
        print(f"  ✓ Data collection tracked: {tracking_info['freshness_score']}")
        
        # Test refresh check
        should_refresh = tracker.should_refresh_data(collected_at)
        print(f"  ✓ Should refresh (fresh data): {should_refresh}")
        
        old_collected = datetime.utcnow() - timedelta(days=10)
        should_refresh = tracker.should_refresh_data(old_collected)
        print(f"  ✓ Should refresh (stale data): {should_refresh}")
        
        # Test freshness info
        info = tracker.get_freshness_info(collected_at)
        print(f"  ✓ Freshness info: age_hours={info['age_hours']:.2f}")
        
        print("  ✅ Freshness tracker tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Freshness tracker test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_data_connector():
    """Test data connector"""
    print("Testing data connector...")
    try:
        from app.data.connector import DataConnector
        from app.data.scraper import WebScraper
        from app.data.company_registry import CompanyRegistryFetcher
        
        connector = DataConnector()
        print("  ✓ DataConnector initialized")
        
        # Register sources
        scraper = WebScraper(name="test_scraper", rate_limit=10)
        registry = CompanyRegistryFetcher(name="test_registry", rate_limit=5)
        
        connector.register_source(scraper)
        connector.register_source(registry)
        print(f"  ✓ Sources registered: {len(connector.sources)}")
        
        # Get source info
        source_info = connector.get_source_info()
        print(f"  ✓ Source info retrieved: {len(source_info)} sources")
        
        # Test query (without actually fetching - just test structure)
        query = {
            "client": "Test Company",
            "client_country": "US",
            "client_role": "Export",
            "product_name": "Test Product"
        }
        
        # Note: We won't actually run collection to avoid making real API calls
        print("  ✓ Query structure validated")
        print("  ✓ Data connector ready for use")
        
        print("  ✅ Data connector tests passed")
        return True
    except Exception as e:
        print(f"  ❌ Data connector test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all Stage 2 tests"""
    print("=" * 60)
    print("Stage 2 Testing - Data Collection & Integration")
    print("=" * 60)
    print()
    
    tests = [
        ("Web Scraper", test_web_scraper),
        ("Company Registry", test_company_registry),
        ("Sanctions Checker", test_sanctions_checker),
        ("Data Validator", test_data_validator),
        ("Data Storage", test_data_storage),
        ("Error Handling", test_error_handling),
        ("Freshness Tracker", test_freshness_tracker),
        ("Data Connector", test_data_connector),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print()
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"  ❌ Test '{test_name}' crashed: {e}")
            results.append((test_name, False))
    
    print()
    print("=" * 60)
    print("Test Summary")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print()
    print(f"Total: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("🎉 All Stage 2 tests passed!")
        return 0
    else:
        print(f"⚠️  {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    from datetime import timedelta
    sys.exit(main())

