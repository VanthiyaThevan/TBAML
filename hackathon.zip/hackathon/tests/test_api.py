"""
Test API Endpoints
Test all API endpoints to verify they're working
"""

import requests
import json
from typing import Dict, Any


class APITester:
    """Test API endpoints"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        """Initialize API tester"""
        self.base_url = base_url
        self.results = {
            "passed": [],
            "failed": []
        }
    
    def test_health(self) -> bool:
        """Test health check endpoint"""
        print("=" * 80)
        print("TEST 1: Health Check Endpoint")
        print("=" * 80)
        
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Health check passed")
                print(f"   Status: {data.get('status')}")
                print(f"   Version: {data.get('version')}")
                self.results["passed"].append("Health Check")
                return True
            else:
                print(f"❌ Health check failed: {response.status_code}")
                self.results["failed"].append(f"Health Check: {response.status_code}")
                return False
        except requests.exceptions.ConnectionError:
            print(f"❌ Cannot connect to {self.base_url}")
            print(f"   Make sure the server is running:")
            print(f"   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload")
            self.results["failed"].append("Health Check: Connection error")
            return False
        except Exception as e:
            print(f"❌ Health check error: {str(e)}")
            self.results["failed"].append(f"Health Check: {str(e)}")
            return False
        finally:
            print()
    
    def test_uc1_endpoint(self) -> bool:
        """Test UC1 main endpoint"""
        print("=" * 80)
        print("TEST 2: UC1 Main Endpoint (POST /api/v1/lob/verify)")
        print("=" * 80)
        
        test_data = {
            "client": "Shell plc",
            "client_country": "GB",
            "client_role": "Export",
            "product_name": "Oil & Gas"
        }
        
        try:
            print(f"Request: {json.dumps(test_data, indent=2)}")
            print("Sending request...")
            
            response = requests.post(
                f"{self.base_url}/api/v1/lob/verify",
                json=test_data,
                timeout=120  # AI analysis may take time
            )
            
            if response.status_code == 200:
                data = response.json()
                
                print(f"✅ UC1 endpoint passed")
                print(f"   Status: {response.status_code}")
                print(f"   Verification ID: {data.get('id')}")
                print(f"   Company: {data.get('client') or test_data['client']}")
                print(f"   Activity Level: {data.get('activity_level')}")
                print(f"   Flags: {len(data.get('flags', []))} flags")
                print(f"   Sources: {len(data.get('sources', []))} sources")
                print(f"   Red Flag: {data.get('is_red_flag')}")
                
                if data.get('ai_response'):
                    print(f"   AI Response: {len(data['ai_response'])} chars")
                    print(f"   Preview: {data['ai_response'][:200]}...")
                
                self.results["passed"].append("UC1 Endpoint")
                return True
            else:
                print(f"❌ UC1 endpoint failed: {response.status_code}")
                print(f"   Response: {response.text[:500]}")
                self.results["failed"].append(f"UC1 Endpoint: {response.status_code}")
                return False
                
        except requests.exceptions.ConnectionError:
            print(f"❌ Cannot connect to {self.base_url}")
            self.results["failed"].append("UC1 Endpoint: Connection error")
            return False
        except Exception as e:
            print(f"❌ UC1 endpoint error: {str(e)}")
            self.results["failed"].append(f"UC1 Endpoint: {str(e)}")
            return False
        finally:
            print()
    
    def test_get_endpoint(self, verification_id: int = 1) -> bool:
        """Test get verification endpoint"""
        print("=" * 80)
        print(f"TEST 3: Get Verification Endpoint (GET /api/v1/lob/{verification_id})")
        print("=" * 80)
        
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/lob/{verification_id}",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Get endpoint passed")
                print(f"   ID: {data.get('id')}")
                print(f"   Company: {data.get('client')}")
                print(f"   Activity Level: {data.get('activity_level')}")
                self.results["passed"].append("Get Endpoint")
                return True
            elif response.status_code == 404:
                print(f"⚠️  Verification {verification_id} not found (404)")
                print(f"   This is OK if the ID doesn't exist")
                self.results["passed"].append("Get Endpoint (404 handling)")
                return True
            else:
                print(f"❌ Get endpoint failed: {response.status_code}")
                self.results["failed"].append(f"Get Endpoint: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Get endpoint error: {str(e)}")
            self.results["failed"].append(f"Get Endpoint: {str(e)}")
            return False
        finally:
            print()
    
    def test_list_endpoint(self) -> bool:
        """Test list verifications endpoint"""
        print("=" * 80)
        print("TEST 4: List Verifications Endpoint (GET /api/v1/lob)")
        print("=" * 80)
        
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/lob?limit=5",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ List endpoint passed")
                print(f"   Records returned: {len(data)}")
                
                if data:
                    print(f"   First record:")
                    print(f"     ID: {data[0].get('id')}")
                    print(f"     Company: {data[0].get('client')}")
                
                self.results["passed"].append("List Endpoint")
                return True
            else:
                print(f"❌ List endpoint failed: {response.status_code}")
                self.results["failed"].append(f"List Endpoint: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ List endpoint error: {str(e)}")
            self.results["failed"].append(f"List Endpoint: {str(e)}")
            return False
        finally:
            print()
    
    def test_error_handling(self) -> bool:
        """Test error handling"""
        print("=" * 80)
        print("TEST 5: Error Handling")
        print("=" * 80)
        
        # Test invalid input
        invalid_data = {
            "client": "",
            "client_country": "USA",  # Invalid length
            "client_role": "Invalid",  # Invalid role
            "product_name": ""
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/lob/verify",
                json=invalid_data,
                timeout=10
            )
            
            if response.status_code in [400, 422]:
                print(f"✅ Error handling working (invalid input rejected)")
                print(f"   Status: {response.status_code}")
                self.results["passed"].append("Error Handling")
                return True
            else:
                print(f"⚠️  Unexpected status: {response.status_code}")
                self.results["failed"].append(f"Error Handling: Status {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Error handling test error: {str(e)}")
            self.results["failed"].append(f"Error Handling: {str(e)}")
            return False
        finally:
            print()
    
    def test_swagger_docs(self) -> bool:
        """Test Swagger documentation"""
        print("=" * 80)
        print("TEST 6: Swagger Documentation")
        print("=" * 80)
        
        try:
            response = requests.get(f"{self.base_url}/docs", timeout=5)
            
            if response.status_code == 200:
                print(f"✅ Swagger UI available")
                print(f"   Visit: {self.base_url}/docs")
                self.results["passed"].append("Swagger Docs")
                return True
            else:
                print(f"❌ Swagger UI failed: {response.status_code}")
                self.results["failed"].append(f"Swagger Docs: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Swagger docs error: {str(e)}")
            self.results["failed"].append(f"Swagger Docs: {str(e)}")
            return False
        finally:
            print()
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Run all API tests"""
        print("=" * 80)
        print("API VALIDATION TESTS")
        print("=" * 80)
        print(f"Base URL: {self.base_url}")
        print()
        
        # Run tests
        self.test_health()
        self.test_swagger_docs()
        self.test_list_endpoint()
        self.test_get_endpoint()
        self.test_error_handling()
        self.test_uc1_endpoint()
        
        # Print summary
        print("=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        print()
        
        total = len(self.results["passed"]) + len(self.results["failed"])
        passed = len(self.results["passed"])
        failed = len(self.results["failed"])
        
        print(f"Total Tests: {total}")
        print(f"✅ Passed: {passed}")
        print(f"❌ Failed: {failed}")
        print()
        
        if self.results["passed"]:
            print("✅ Passed Tests:")
            for test in self.results["passed"]:
                print(f"   - {test}")
            print()
        
        if self.results["failed"]:
            print("❌ Failed Tests:")
            for test in self.results["failed"]:
                print(f"   - {test}")
            print()
        
        if failed == 0:
            print("🎉 ALL API TESTS PASSED!")
        else:
            print(f"⚠️  {failed} TEST(S) FAILED")
        
        print("=" * 80)
        
        return self.results


if __name__ == "__main__":
    import sys
    
    base_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
    
    tester = APITester(base_url=base_url)
    results = tester.run_all_tests()
    
    # Exit with appropriate code
    if len(results["failed"]) > 0:
        sys.exit(1)
    else:
        sys.exit(0)


