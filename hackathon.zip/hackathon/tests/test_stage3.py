"""
Test Stage 3: AI/ML Model Development
Tests all AI components
"""

from app.ai.config import AIConfig
from app.ai.llm_client import LLMClient
from app.ai.text_processor import TextProcessor
from app.ai.classifier import ActivityClassifier, RiskClassifier
from app.ai.flag_generator import FlagGenerator
from app.ai.orchestrator import AIOrchestrator
from app.core.logging import get_logger

logger = get_logger(__name__)


def test_text_processor():
    """Test text processor"""
    print("=" * 80)
    print("TESTING: Text Processor")
    print("=" * 80)
    
    processor = TextProcessor()
    
    sample_text = """
    Vitol Group is a major international energy trading company based in the Netherlands.
    The company trades crude oil, refined products, natural gas, and other energy commodities.
    Founded in 1966, Vitol has operations in 40 countries and handles approximately 8 million
    barrels of crude oil and products per day. The company is privately owned and does not
    disclose detailed financial information.
    """
    
    features = processor.extract_features(sample_text)
    
    print(f"Features extracted:")
    print(f"  Word count: {features['word_count']}")
    print(f"  Has company mention: {features['has_company_mention']}")
    print(f"  Has location mention: {features['has_location_mention']}")
    print(f"  Has activity mention: {features['has_activity_mention']}")
    print(f"  Entities found: {len(features['extracted_entities'])}")
    print(f"  Quality score: {features['text_quality_score']:.2f}")
    print()
    
    return True


def test_llm_client():
    """Test LLM client"""
    print("=" * 80)
    print("TESTING: LLM Client")
    print("=" * 80)
    
    try:
        llm = LLMClient()
        
        test_prompt = "What is a trade-based money laundering scheme? Answer in one sentence."
        
        print(f"Testing with provider: {llm.config.llm_provider}")
        print(f"Prompt: {test_prompt}")
        print("Generating response...")
        
        response = llm.generate_response(prompt=test_prompt)
        
        if response.get("error"):
            print(f"❌ Error: {response['error']}")
            print("   (This may be due to missing API key or network issue)")
            return False
        
        content = response.get("content", "")
        if content:
            print(f"✅ Response received ({len(content)} chars)")
            print(f"   Preview: {content[:200]}...")
            print(f"   Provider: {response.get('metadata', {}).get('provider', 'unknown')}")
            return True
        else:
            print("❌ No content in response")
            return False
    
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return False
    finally:
        print()


def test_classifiers():
    """Test activity and risk classifiers"""
    print("=" * 80)
    print("TESTING: Classifiers")
    print("=" * 80)
    
    sample_text = """
    Shell plc is a British multinational oil and gas company headquartered in London.
    The company operates in over 70 countries and employs around 93,000 people.
    Shell is one of the world's largest oil companies and has been actively trading
    in energy markets for over 100 years. Recent reports show continued operations
    and business activity across all major markets.
    """
    
    try:
        activity_classifier = ActivityClassifier()
        print("Testing Activity Classifier...")
        
        result = activity_classifier.classify(
            company_name="Shell plc",
            evidence_text=sample_text
        )
        
        print(f"  Activity Level: {result.get('activity_level')}")
        print(f"  Confidence: {result.get('confidence')}")
        print(f"  Reasoning: {result.get('reasoning', '')[:200]}...")
        print()
        
        risk_classifier = RiskClassifier()
        print("Testing Risk Classifier...")
        
        risk_result = risk_classifier.assess_risk(
            company_name="Shell plc",
            country="GB",
            evidence_text=sample_text
        )
        
        print(f"  Risk Score: {risk_result.get('risk_score', 0):.2f}")
        print(f"  Risk Level: {risk_result.get('risk_level')}")
        print(f"  Flags: {len(risk_result.get('flags', []))}")
        print()
        
        return True
    
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        print()


def test_flag_generator():
    """Test flag generator"""
    print("=" * 80)
    print("TESTING: Flag Generator")
    print("=" * 80)
    
    sample_text = """
    The company has limited online presence and no verifiable registration information.
    Address information could not be confirmed through standard business registries.
    """
    
    try:
        flag_generator = FlagGenerator()
        
        flags = flag_generator.generate_flags(
            company_name="Test Company",
            country="US",
            evidence_text=sample_text
        )
        
        print(f"Generated {len(flags)} flags:")
        for i, flag in enumerate(flags[:5], 1):  # Show first 5
            print(f"  {i}. [{flag.get('severity', 'unknown').upper()}] {flag.get('category')}: {flag.get('message')}")
        print()
        
        formatted = flag_generator.format_flags_for_storage(flags)
        print(f"Formatted flags ({len(formatted)}):")
        for flag in formatted[:3]:
            print(f"  - {flag}")
        print()
        
        return True
    
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        print()


def test_ai_orchestrator():
    """Test complete AI orchestrator"""
    print("=" * 80)
    print("TESTING: AI Orchestrator (Complete UC1 Analysis)")
    print("=" * 80)
    
    try:
        orchestrator = AIOrchestrator()
        
        input_data = {
            "client": "Shell plc",
            "client_country": "GB",
            "client_role": "Export",
            "product_name": "Oil & Gas"
        }
        
        collected_data = {
            "sources": [
                {
                    "name": "web_scraper",
                    "content": "Shell is a major energy company with global operations."
                },
                {
                    "name": "company_registry",
                    "content": "Registered in UK, established in 1907."
                }
            ],
            "data": {
                "website_content": "Shell operates in 70+ countries with 93,000 employees.",
                "description": "British multinational oil and gas company"
            }
        }
        
        aggregated_data = {
            "data": {
                "url": "https://www.shell.com",
                "description": collected_data["data"]["description"]
            },
            "sources": ["web_scraper", "company_registry"]
        }
        
        print("Running complete LOB analysis...")
        print(f"Company: {input_data['client']} ({input_data['client_country']})")
        print()
        
        result = orchestrator.analyze_lob(
            input_data=input_data,
            collected_data=collected_data,
            aggregated_data=aggregated_data
        )
        
        print("✅ Analysis Complete!")
        print()
        print("Results:")
        print(f"  Activity Level: {result.get('activity_level')}")
        print(f"  Risk Level: {result.get('risk_level')} (score: {result.get('risk_score', 0):.2f})")
        print(f"  Confidence: {result.get('confidence_score')}")
        print(f"  Red Flag: {result.get('is_red_flag')}")
        print(f"  Flags Generated: {len(result.get('flags', []))}")
        print()
        print("AI Response Preview:")
        ai_response = result.get('ai_response', '')
        print(f"  {ai_response[:300]}..." if len(ai_response) > 300 else f"  {ai_response}")
        print()
        
        return True
    
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        print()


def main():
    """Run all Stage 3 tests"""
    print("=" * 80)
    print("STAGE 3: AI/ML MODEL DEVELOPMENT - TESTING")
    print("=" * 80)
    print()
    
    results = {}
    
    # Test 1: Text Processor
    results['text_processor'] = test_text_processor()
    
    # Test 2: LLM Client (may fail if API key missing)
    results['llm_client'] = test_llm_client()
    
    # Test 3: Classifiers
    results['classifiers'] = test_classifiers()
    
    # Test 4: Flag Generator
    results['flag_generator'] = test_flag_generator()
    
    # Test 5: Complete Orchestrator
    results['orchestrator'] = test_ai_orchestrator()
    
    # Summary
    print("=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print()
    
    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test_name}: {status}")
    
    print()
    passed_count = sum(1 for p in results.values() if p)
    total_count = len(results)
    print(f"Results: {passed_count}/{total_count} tests passed")
    print()
    
    if passed_count == total_count:
        print("✅ All Stage 3 components working!")
    elif passed_count >= total_count - 1:  # Allow LLM to fail (API key issue)
        print("⚠️  Most components working (LLM may need API key)")
    else:
        print("❌ Some components need attention")
    
    print("=" * 80)


if __name__ == "__main__":
    main()

