"""
Test EU Sanctions integration with sanctions checker
"""

from app.data.sanctions_checker import SanctionsChecker
import json

print("Testing EU Sanctions Integration...")
print("=" * 80)

checker = SanctionsChecker()

test_cases = [
    {"client": "Saddam Hussein", "client_country": "IQ"},  # We saw this in the XML
    {"client": "Apple Inc.", "client_country": "US"},  # Should not match
    {"client": "Test Company", "client_country": "EU"},  # Should not match
]

for test_case in test_cases:
    print(f"\n{'=' * 80}")
    print(f"Testing: {test_case['client']} ({test_case['client_country']})")
    print("=" * 80)
    
    try:
        result = checker.fetch_data(test_case)
        
        print(f"\nResult:")
        print(f"  Entity: {result.get('entity_name')}")
        print(f"  Is Sanctioned: {result.get('is_sanctioned')}")
        print(f"  Matches: {len(result.get('matches', []))}")
        
        eu_check = result.get('sanctions_checks', {}).get('eu', {})
        if eu_check:
            print(f"\nEU Sanctions Check:")
            print(f"  Source: {eu_check.get('source')}")
            print(f"  Match: {eu_check.get('match')}")
            print(f"  Match Count: {eu_check.get('match_count', 0)}")
            print(f"  Note: {eu_check.get('note')}")
            
            if eu_check.get('matches'):
                print(f"\n  Match Details:")
                for i, match in enumerate(eu_check.get('matches', [])[:2], 1):
                    print(f"    Match {i}:")
                    print(f"      Logical ID: {match.get('logical_id')}")
                    print(f"      Names: {match.get('names', [])[:3]}")
                    print(f"      Subject Type: {match.get('subject_type')}")
        
        print(f"\nFull Result (JSON snippet):")
        print(json.dumps(result, indent=2, default=str)[:800])
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()

print("\n" + "=" * 80)
print("EU Sanctions Integration Test Complete!")

