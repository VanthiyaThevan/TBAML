"""
Test OFAC parser
"""

from app.data.ofac_parser import OFACSDNParser
import time

print("Testing OFAC SDN Parser...")
print("=" * 80)

# Create parser instance
parser = OFACSDNParser()

# Check if file exists
print(f"\nFile path: {parser.xml_file_path}")
print(f"File exists: {parser.xml_file_path.exists()}")

if parser.xml_file_path.exists():
    file_size_mb = parser.xml_file_path.stat().st_size / (1024 * 1024)
    print(f"File size: {file_size_mb:.2f} MB")
    
    print("\nLoading OFAC SDN file...")
    start_time = time.time()
    
    success = parser.load_file()
    
    elapsed = time.time() - start_time
    print(f"\nLoad time: {elapsed:.2f} seconds")
    print(f"Success: {success}")
    
    if success:
        stats = parser.get_statistics()
        print("\nStatistics:")
        print(f"  Total entries: {stats.get('total_entries', 0)}")
        print(f"  Total names: {stats.get('total_names', 0)}")
        print(f"  Indexed names: {stats.get('indexed_names', 0)}")
        
        # Test search
        print("\n" + "=" * 80)
        print("Testing searches...")
        
        test_names = [
            "Shell",
            "Exxon",
            "BP",
            "Terrorist",
            "AERO-CARIBBEAN"  # From the grep we saw earlier
        ]
        
        for test_name in test_names:
            print(f"\nSearching for: '{test_name}'")
            matches = parser.search_entity(test_name, exact_match=False)
            print(f"  Found {len(matches)} match(es)")
            
            if matches:
                for i, match in enumerate(matches[:3], 1):  # Show first 3
                    print(f"  Match {i}:")
                    print(f"    Profile ID: {match.get('profile_id', 'N/A')}")
                    print(f"    Names: {match.get('names', [])[:3]}")  # First 3 names
                    print(f"    Programs: {match.get('programs', [])[:2]}")  # First 2 programs
    else:
        print("\nFailed to load file. Check logs for errors.")
else:
    print(f"\nError: OFAC SDN file not found at {parser.xml_file_path}")
    print("Please ensure the file has been downloaded.")

print("\n" + "=" * 80)

