"""
Test OFAC integration with sanctions checker
"""

from app.data.sanctions_checker import SanctionsChecker
import json

print("Testing OFAC Integration with Sanctions Checker...")
print("=" * 80)

checker = SanctionsChecker()

test_cases = [
    {"client": "Shell plc", "client_country": "GB"},
    {"client": "AERO-CARIBBEAN", "client_country": "CU"},  # We saw this in the XML
    {"client": "ExxonMobil", "client_country": "US"},
    {"client": "Random Company Name", "client_country": "US"},  # Should not match
]

for test_case in test_cases:
    print(f"\n{'=' * 80}")
    print(f"Testing: {test_case['client']} ({test_case['client_country']})")
    print("=" * 80)
    
    try:
        result = checker.fetch_data(test_case)
        
        print(f"\nResult:")
        print(f"  Entity: {result.get('entity_name')}")
        print(f"  Is Sanctioned: {result.get('is_sanctioned')}")
        print(f"  Matches: {len(result.get('matches', []))}")
        
        ofac_check = result.get('sanctions_checks', {}).get('ofac', {})
        if ofac_check:
            print(f"\nOFAC Check:")
            print(f"  Source: {ofac_check.get('source')}")
            print(f"  Match: {ofac_check.get('match')}")
            print(f"  Match Count: {ofac_check.get('match_count', 0)}")
            print(f"  Note: {ofac_check.get('note')}")
            
            if ofac_check.get('matches'):
                print(f"\n  Match Details:")
                for i, match in enumerate(ofac_check.get('matches', [])[:2], 1):
                    print(f"    Match {i}:")
                    print(f"      Profile ID: {match.get('profile_id')}")
                    print(f"      Names: {match.get('names', [])[:3]}")
                    print(f"      Programs: {match.get('programs', [])[:2]}")
        
        # Pretty print full result
        print(f"\nFull Result (JSON):")
        print(json.dumps(result, indent=2, default=str)[:500])
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()

print("\n" + "=" * 80)
print("Integration Test Complete!")

