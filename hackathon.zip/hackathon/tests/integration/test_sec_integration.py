"""
Test SEC EDGAR integration with company registry
"""

from app.data.company_registry import CompanyRegistryFetcher
import json

print("Testing SEC EDGAR Integration with Company Registry...")
print("=" * 80)

fetcher = CompanyRegistryFetcher()

test_cases = [
    {"client": "Microsoft Corporation", "client_country": "US"},
    {"client": "Apple Inc.", "client_country": "US"},
    {"client": "ExxonMobil", "client_country": "US"},
    {"client": "Shell plc", "client_country": "US"},  # Should not match (not US company)
    {"client": "NVDA", "client_country": "US"},  # Test ticker search
]

for test_case in test_cases:
    print(f"\n{'=' * 80}")
    print(f"Testing: {test_case['client']} ({test_case['client_country']})")
    print("=" * 80)
    
    try:
        result = fetcher.fetch_data(test_case)
        
        print(f"\nResult:")
        print(f"  Company: {result.get('company_name')}")
        print(f"  Sources: {result.get('sources', [])}")
        
        sec_data = result.get('registry_data', {}).get('us', {})
        if sec_data:
            print(f"\nSEC EDGAR Data:")
            print(f"  Source: {sec_data.get('source')}")
            print(f"  Company Name: {sec_data.get('company_name')}")
            print(f"  Ticker: {sec_data.get('ticker')}")
            print(f"  CIK: {sec_data.get('cik')}")
            print(f"  Match Type: {sec_data.get('match_type')}")
            print(f"  SEC URL: {sec_data.get('sec_url', 'N/A')}")
            print(f"  Note: {sec_data.get('note')}")
        
        # Pretty print full result
        print(f"\nFull Result (JSON):")
        print(json.dumps(result, indent=2, default=str)[:1000])
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()

print("\n" + "=" * 80)
print("SEC Integration Test Complete!")

