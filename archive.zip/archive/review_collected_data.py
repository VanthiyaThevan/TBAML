"""
Review Collected Data
Comprehensive review of all scraped and collected company data
"""

import json
from datetime import datetime
from app.models.base import get_session_factory
from app.models.lob import LOBVerification
from app.data.date_extractor import PublicationDateExtractor


def format_json(data):
    """Format JSON for display"""
    if isinstance(data, (dict, list)):
        return json.dumps(data, indent=2, ensure_ascii=False)
    return str(data)


def review_all_data(export_to_file=False):
    """Review all collected data"""
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        verifications = db.query(LOBVerification).order_by(
            LOBVerification.created_at.desc()
        ).all()
        
        print("=" * 100)
        print("COMPREHENSIVE DATA REVIEW")
        print("=" * 100)
        print(f"\nTotal Records: {len(verifications)}\n")
        
        review_data = []
        
        for i, v in enumerate(verifications, 1):
            print(f"{'='*100}")
            print(f"RECORD #{i} - ID: {v.id}")
            print(f"{'='*100}\n")
            
            record_info = {
                "id": v.id,
                "company_name": v.client,
                "country": v.client_country,
                "role": v.client_role,
                "product": v.product_name
            }
            
            # Basic Info
            print("📋 COMPANY INFORMATION:")
            print(f"  Name: {v.client}")
            print(f"  Country: {v.client_country}")
            print(f"  Role: {v.client_role}")
            print(f"  Product: {v.product_name}")
            print()
            
            # Website Data
            print("🌐 WEBSITE DATA:")
            if v.website_source:
                print(f"  URL: {v.website_source}")
                record_info["website_url"] = v.website_source
            else:
                print("  URL: Not found")
                record_info["website_url"] = None
            
            if v.publication_date:
                print(f"  Publication Date: {v.publication_date}")
                record_info["publication_date"] = v.publication_date
            else:
                print("  Publication Date: Not extracted")
                record_info["publication_date"] = None
            print()
            
            # Data Sources
            print("📡 DATA SOURCES:")
            if v.sources:
                sources_list = v.sources if isinstance(v.sources, list) else [v.sources]
                print(f"  Total Sources: {len(sources_list)}")
                record_info["sources"] = []
                
                for j, source in enumerate(sources_list, 1):
                    if isinstance(source, dict):
                        source_name = source.get('name', 'Unknown')
                        source_url = source.get('url', 'N/A')
                        collected_at = source.get('collected_at', 'N/A')
                        print(f"  {j}. {source_name}")
                        if source_url and source_url != 'N/A':
                            print(f"     URL: {source_url}")
                        if collected_at and collected_at != 'N/A':
                            print(f"     Collected: {collected_at}")
                        
                        record_info["sources"].append({
                            "name": source_name,
                            "url": source_url,
                            "collected_at": collected_at
                        })
                    else:
                        print(f"  {j}. {source}")
                        record_info["sources"].append({"name": str(source)})
            else:
                print("  No sources")
                record_info["sources"] = []
            print()
            
            # UC1 Output Fields Status
            print("📊 UC1 OUTPUT FIELDS STATUS:")
            uc1_status = {}
            
            # AI Response
            if v.ai_response:
                print(f"  ✅ AI Response: Present ({len(v.ai_response)} chars)")
                uc1_status["ai_response"] = True
                uc1_status["ai_response_preview"] = v.ai_response[:200] + "..." if len(v.ai_response) > 200 else v.ai_response
            else:
                print("  ❌ AI Response: Missing")
                uc1_status["ai_response"] = False
            
            # Activity Level
            if v.activity_level:
                print(f"  ✅ Activity Level: {v.activity_level}")
                uc1_status["activity_level"] = v.activity_level
            else:
                print("  ❌ Activity Level: Missing")
                uc1_status["activity_level"] = None
            
            # Flags
            if v.flags:
                flags_list = v.flags if isinstance(v.flags, list) else [v.flags]
                if isinstance(flags_list, list) and len(flags_list) > 0 and flags_list[0]:
                    print(f"  ✅ Flags: {len(flags_list)} flag(s)")
                    for flag in flags_list[:3]:  # Show first 3
                        print(f"     - {flag}")
                    uc1_status["flags"] = flags_list
                else:
                    print("  ⚠️  Flags: Field exists but empty")
                    uc1_status["flags"] = []
            else:
                print("  ❌ Flags: Missing")
                uc1_status["flags"] = []
            
            # Publication Date
            if v.publication_date:
                print(f"  ✅ Publication Date: {v.publication_date}")
                uc1_status["publication_date"] = True
            else:
                print("  ❌ Publication Date: Missing")
                uc1_status["publication_date"] = False
            
            # Sources
            if v.sources:
                print(f"  ✅ Sources: {len(v.sources) if isinstance(v.sources, list) else 1} source(s)")
                uc1_status["sources"] = True
            else:
                print("  ❌ Sources: Missing")
                uc1_status["sources"] = False
            
            record_info["uc1_status"] = uc1_status
            print()
            
            # Timestamps
            print("📅 METADATA:")
            print(f"  Created: {v.created_at}")
            print(f"  Updated: {v.updated_at}")
            if v.data_collected_at:
                print(f"  Data Collected: {v.data_collected_at}")
            if v.last_verified_at:
                print(f"  Last Verified: {v.last_verified_at}")
            if v.data_freshness_score:
                print(f"  Freshness: {v.data_freshness_score}")
            print()
            
            # Red Flag Status
            if v.is_red_flag:
                print("  ⚠️  RED FLAG: This company has been flagged")
            else:
                print("  ✅ No red flags")
            print()
            
            review_data.append(record_info)
        
        # Summary Statistics
        print("=" * 100)
        print("SUMMARY STATISTICS")
        print("=" * 100)
        print()
        
        total = len(verifications)
        with_website = sum(1 for v in verifications if v.website_source)
        with_pub_date = sum(1 for v in verifications if v.publication_date)
        with_ai = sum(1 for v in verifications if v.ai_response)
        with_activity = sum(1 for v in verifications if v.activity_level)
        with_flags = sum(1 for v in verifications if v.flags and 
                        (isinstance(v.flags, list) and len(v.flags) > 0 or 
                         isinstance(v.flags, str) and v.flags.strip()))
        with_sources = sum(1 for v in verifications if v.sources)
        red_flags = sum(1 for v in verifications if v.is_red_flag)
        
        print(f"Total Records: {total}")
        print(f"Companies with Website URL: {with_website}/{total} ({with_website/total*100:.1f}%)")
        print(f"Companies with Publication Date: {with_pub_date}/{total} ({with_pub_date/total*100:.1f}%)")
        print(f"Companies with AI Response: {with_ai}/{total} ({with_ai/total*100:.1f}%)")
        print(f"Companies with Activity Level: {with_activity}/{total} ({with_activity/total*100:.1f}%)")
        print(f"Companies with Flags: {with_flags}/{total} ({with_flags/total*100:.1f}%)")
        print(f"Companies with Sources: {with_sources}/{total} ({with_sources/total*100:.1f}%)")
        print(f"Companies with Red Flags: {red_flags}/{total} ({red_flags/total*100:.1f}%)")
        print()
        
        # UC1 Completeness
        print("UC1 OUTPUT COMPLETENESS:")
        uc1_fields = ["ai_response", "publication_date", "activity_level", "flags", "sources"]
        completed = sum([
            with_ai == total,
            with_pub_date == total,
            with_activity == total,
            with_flags == total,
            with_sources == total
        ])
        print(f"  {completed}/5 fields complete")
        print()
        
        # Export if requested
        if export_to_file:
            filename = f"data_review_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump({
                    "review_date": datetime.now().isoformat(),
                    "statistics": {
                        "total_records": total,
                        "with_website": with_website,
                        "with_publication_date": with_pub_date,
                        "with_ai_response": with_ai,
                        "with_activity_level": with_activity,
                        "with_flags": with_flags,
                        "with_sources": with_sources,
                        "red_flags": red_flags
                    },
                    "records": review_data
                }, f, indent=2, ensure_ascii=False)
            print(f"✅ Review exported to: {filename}")
            print()
        
        print("=" * 100)
        
    finally:
        db.close()


def extract_all_publication_dates():
    """Extract publication dates for all records"""
    print("=" * 100)
    print("EXTRACTING PUBLICATION DATES")
    print("=" * 100)
    print()
    
    extractor = PublicationDateExtractor()
    stats = extractor.update_publication_dates()
    
    print()
    print("=" * 100)
    print("EXTRACTION RESULTS")
    print("=" * 100)
    print()
    print(f"Total Records Processed: {stats['total']}")
    print(f"Successfully Updated: {stats['updated']}")
    print(f"Skipped (no date found): {stats['skipped']}")
    print(f"Errors: {stats['errors']}")
    print()
    print("=" * 100)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--extract-dates":
            extract_all_publication_dates()
        elif sys.argv[1] == "--export":
            review_all_data(export_to_file=True)
        else:
            review_all_data()
    else:
        # First extract dates, then review
        print("Step 1: Extracting publication dates...\n")
        extract_all_publication_dates()
        print("\n" + "=" * 100 + "\n")
        print("Step 2: Reviewing collected data...\n")
        review_all_data()

