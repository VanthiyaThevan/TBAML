"""
View scraped company data from SQLite database
"""

import json
from sqlalchemy import create_engine, text
from app.models.base import Base, get_session_factory
from app.models.lob import LOBVerification
from app.core.logging import setup_logging, get_logger

setup_logging()
logger = get_logger(__name__)


def view_scraped_data():
    """View all scraped company data from database"""
    
    SessionLocal, engine = get_session_factory()
    db = SessionLocal()
    
    try:
        print("="*80)
        print("SCRAPED COMPANY DATA FROM DATABASE")
        print("="*80)
        print()
        
        # Get all verifications
        verifications = db.query(LOBVerification).order_by(
            LOBVerification.created_at.desc()
        ).all()
        
        print(f"Total companies in database: {len(verifications)}")
        print()
        
        for i, v in enumerate(verifications, 1):
            print("="*80)
            print(f"Company #{i}: {v.client}")
            print("="*80)
            
            # Basic Information
            print(f"\n📍 Basic Information:")
            print(f"   ID: {v.id}")
            print(f"   Company: {v.client}")
            print(f"   Country: {v.client_country}")
            print(f"   Role: {v.client_role}")
            print(f"   Product: {v.product_name}")
            
            # Scraped Data
            print(f"\n🌐 Website Information:")
            if v.website_source:
                print(f"   URL: {v.website_source}")
            else:
                print(f"   URL: Not found")
            
            if v.publication_date:
                print(f"   Publication Date: {v.publication_date}")
            
            # Data Sources
            print(f"\n📊 Data Sources:")
            if v.sources:
                sources_list = v.sources if isinstance(v.sources, list) else json.loads(v.sources) if isinstance(v.sources, str) else []
                print(f"   Total sources: {len(sources_list)}")
                for j, source in enumerate(sources_list, 1):
                    if isinstance(source, dict):
                        print(f"   {j}. {source.get('name', 'Unknown')}")
                        if source.get('url'):
                            print(f"      URL: {source.get('url')}")
                        if source.get('collected_at'):
                            print(f"      Collected: {source.get('collected_at')}")
                    else:
                        print(f"   {j}. {source}")
            else:
                print(f"   No sources recorded")
            
            # Verification Status
            print(f"\n✅ Verification Status:")
            if v.activity_level:
                print(f"   Activity Level: {v.activity_level}")
            if v.is_red_flag:
                print(f"   ⚠️  RED FLAG: {v.is_red_flag}")
            if v.confidence_score:
                print(f"   Confidence Score: {v.confidence_score}")
            if v.flags:
                flags = v.flags if isinstance(v.flags, list) else json.loads(v.flags) if isinstance(v.flags, str) else []
                if flags:
                    print(f"   Flags/Alerts: {len(flags)}")
                    for flag in flags[:5]:  # Show first 5 flags
                        print(f"      - {flag}")
            
            # AI Response (if available)
            if v.ai_response:
                print(f"\n🤖 AI Response:")
                ai_response = v.ai_response[:500] + "..." if len(v.ai_response) > 500 else v.ai_response
                print(f"   {ai_response}")
            
            # Timestamps
            print(f"\n⏰ Timestamps:")
            print(f"   Created: {v.created_at}")
            print(f"   Updated: {v.updated_at}")
            if v.data_collected_at:
                print(f"   Data Collected: {v.data_collected_at}")
            if v.last_verified_at:
                print(f"   Last Verified: {v.last_verified_at}")
            if v.data_freshness_score:
                print(f"   Freshness: {v.data_freshness_score}")
            
            print()
        
        print("="*80)
        print(f"Summary: {len(verifications)} companies total")
        print("="*80)
        
        # Statistics
        print("\n📈 Statistics:")
        with_url = sum(1 for v in verifications if v.website_source)
        with_sources = sum(1 for v in verifications if v.sources)
        with_ai_response = sum(1 for v in verifications if v.ai_response)
        red_flags = sum(1 for v in verifications if v.is_red_flag)
        
        print(f"   Companies with URLs: {with_url}/{len(verifications)}")
        print(f"   Companies with sources: {with_sources}/{len(verifications)}")
        print(f"   Companies with AI response: {with_ai_response}/{len(verifications)}")
        print(f"   Red flags: {red_flags}")
        
    except Exception as e:
        logger.error(f"Error viewing data", error=str(e), exc_info=True)
        print(f"❌ Error: {e}")
    finally:
        db.close()


def view_company_details(company_name: str = None, verification_id: int = None):
    """View detailed data for a specific company"""
    
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        if verification_id:
            verification = db.query(LOBVerification).filter(
                LOBVerification.id == verification_id
            ).first()
        elif company_name:
            verification = db.query(LOBVerification).filter(
                LOBVerification.client.ilike(f"%{company_name}%")
            ).order_by(LOBVerification.created_at.desc()).first()
        else:
            print("❌ Please provide either company_name or verification_id")
            return
        
        if not verification:
            print(f"❌ Company not found")
            return
        
        print("="*80)
        print(f"DETAILED VIEW: {verification.client}")
        print("="*80)
        print()
        
        # Full JSON dump
        print("📋 Full Data (JSON):")
        data = {
            "id": verification.id,
            "client": verification.client,
            "client_country": verification.client_country,
            "client_role": verification.client_role,
            "product_name": verification.product_name,
            "website_source": verification.website_source,
            "publication_date": verification.publication_date,
            "activity_level": verification.activity_level,
            "flags": verification.flags,
            "sources": verification.sources,
            "ai_response": verification.ai_response,
            "is_red_flag": verification.is_red_flag,
            "confidence_score": verification.confidence_score,
            "data_collected_at": verification.data_collected_at.isoformat() if verification.data_collected_at else None,
            "data_freshness_score": verification.data_freshness_score,
            "last_verified_at": verification.last_verified_at.isoformat() if verification.last_verified_at else None,
            "created_at": verification.created_at.isoformat() if verification.created_at else None,
            "updated_at": verification.updated_at.isoformat() if verification.updated_at else None,
        }
        
        print(json.dumps(data, indent=2, default=str))
        
    except Exception as e:
        logger.error(f"Error viewing company details", error=str(e))
        print(f"❌ Error: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1].isdigit():
            # View by ID
            view_company_details(verification_id=int(sys.argv[1]))
        else:
            # View by company name
            view_company_details(company_name=sys.argv[1])
    else:
        # View all
        view_scraped_data()

