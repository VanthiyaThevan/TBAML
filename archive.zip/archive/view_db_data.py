"""
View scraped data directly from SQLite database
Shows all collected data including website content
"""

import sqlite3
import json
from datetime import datetime

def format_datetime(dt_str):
    """Format datetime string"""
    if not dt_str:
        return "N/A"
    try:
        dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return dt_str


def view_all_companies():
    """View all companies from database"""
    
    conn = sqlite3.connect('tbaml_dev.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        print("="*80)
        print("SCRAPED COMPANY DATA - SQLite Database")
        print("="*80)
        print()
        
        # Get all companies
        cursor.execute("""
            SELECT * FROM lob_verifications 
            ORDER BY created_at DESC
        """)
        
        rows = cursor.fetchall()
        
        print(f"Total companies: {len(rows)}")
        print()
        
        for i, row in enumerate(rows, 1):
            print("="*80)
            print(f"Company #{i}: {row['client']}")
            print("="*80)
            
            # Basic Info
            print(f"\n📍 Basic Information:")
            print(f"   ID: {row['id']}")
            print(f"   Company: {row['client']}")
            print(f"   Country: {row['client_country']}")
            print(f"   Role: {row['client_role']}")
            print(f"   Product: {row['product_name']}")
            
            # Website Info
            print(f"\n🌐 Website Information:")
            if row['website_source']:
                print(f"   URL: {row['website_source']}")
            else:
                print(f"   URL: Not found")
            
            # Data Sources
            print(f"\n📊 Data Sources:")
            if row['sources']:
                try:
                    sources = json.loads(row['sources']) if isinstance(row['sources'], str) else row['sources']
                    print(f"   Count: {len(sources)}")
                    for j, source in enumerate(sources, 1):
                        if isinstance(source, dict):
                            print(f"   {j}. {source.get('name', 'Unknown')}")
                            if source.get('url'):
                                print(f"      URL: {source.get('url')}")
                            if source.get('collected_at'):
                                print(f"      Collected: {source.get('collected_at')}")
                        else:
                            print(f"   {j}. {source}")
                except Exception as e:
                    print(f"   {row['sources'][:100]}...")
            else:
                print("   No sources")
            
            # AI Response
            if row['ai_response']:
                print(f"\n🤖 AI Response:")
                ai_resp = row['ai_response'][:500] + "..." if len(row['ai_response']) > 500 else row['ai_response']
                print(f"   {ai_resp}")
            
            # Activity & Flags
            print(f"\n✅ Status:")
            if row['activity_level']:
                print(f"   Activity Level: {row['activity_level']}")
            if row['is_red_flag']:
                print(f"   ⚠️  RED FLAG: {row['is_red_flag']}")
            if row['confidence_score']:
                print(f"   Confidence: {row['confidence_score']}")
            
            if row['flags']:
                try:
                    flags = json.loads(row['flags']) if isinstance(row['flags'], str) else row['flags']
                    if flags and len(flags) > 0:
                        print(f"\n⚠️  Flags/Alerts ({len(flags)}):")
                        for flag in flags[:5]:
                            print(f"   - {flag}")
                except:
                    pass
            
            # Timestamps
            print(f"\n⏰ Timestamps:")
            print(f"   Created: {format_datetime(row['created_at'])}")
            print(f"   Updated: {format_datetime(row['updated_at'])}")
            if row['data_collected_at']:
                print(f"   Data Collected: {format_datetime(row['data_collected_at'])}")
            if row['data_freshness_score']:
                print(f"   Freshness: {row['data_freshness_score']}")
            if row['last_verified_at']:
                print(f"   Last Verified: {format_datetime(row['last_verified_at'])}")
            
            print()
        
        # Summary statistics
        print("="*80)
        print("SUMMARY STATISTICS")
        print("="*80)
        
        cursor.execute("SELECT COUNT(*) FROM lob_verifications")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM lob_verifications WHERE website_source IS NOT NULL")
        with_url = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM lob_verifications WHERE sources IS NOT NULL")
        with_sources = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM lob_verifications WHERE ai_response IS NOT NULL")
        with_ai = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM lob_verifications WHERE is_red_flag = 1")
        red_flags = cursor.fetchone()[0]
        
        print(f"Total companies: {total}")
        print(f"Companies with URLs: {with_url}")
        print(f"Companies with sources: {with_sources}")
        print(f"Companies with AI response: {with_ai}")
        print(f"Red flags: {red_flags}")
        
        # Group by country
        cursor.execute("""
            SELECT client_country, COUNT(*) as count 
            FROM lob_verifications 
            GROUP BY client_country 
            ORDER BY count DESC
        """)
        
        print(f"\nBy Country:")
        for row in cursor.fetchall():
            print(f"   {row['client_country']}: {row['count']}")
        
        print("="*80)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        conn.close()


def view_company(company_name: str):
    """View specific company"""
    
    conn = sqlite3.connect('tbaml_dev.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT * FROM lob_verifications 
            WHERE client LIKE ? 
            ORDER BY created_at DESC 
            LIMIT 1
        """, (f"%{company_name}%",))
        
        row = cursor.fetchone()
        
        if not row:
            print(f"❌ Company '{company_name}' not found")
            return
        
        print("="*80)
        print(f"COMPANY: {row['client']}")
        print("="*80)
        print()
        
        print("Basic Information:")
        print(f"   ID: {row['id']}")
        print(f"   Country: {row['client_country']}")
        print(f"   Role: {row['client_role']}")
        print(f"   Product: {row['product_name']}")
        print()
        
        print("Website:")
        print(f"   URL: {row['website_source'] or 'Not found'}")
        print()
        
        print("Data Sources:")
        if row['sources']:
            sources = json.loads(row['sources']) if isinstance(row['sources'], str) else row['sources']
            for source in sources:
                if isinstance(source, dict):
                    print(f"   - {source.get('name')}: {source.get('url', 'N/A')}")
                else:
                    print(f"   - {source}")
        print()
        
        if row['ai_response']:
            print("AI Response:")
            print(f"   {row['ai_response']}")
            print()
        
        if row['flags']:
            flags = json.loads(row['flags']) if isinstance(row['flags'], str) else row['flags']
            if flags:
                print("Flags:")
                for flag in flags:
                    print(f"   - {flag}")
        
        print()
        print(f"Created: {format_datetime(row['created_at'])}")
        print(f"Freshness: {row['data_freshness_score'] or 'N/A'}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        conn.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        view_company(sys.argv[1])
    else:
        view_all_companies()

