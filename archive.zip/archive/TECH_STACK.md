# TBAML System - Tech Stack

## Backend Stack

### Core Framework
- **Python 3.11+** - Modern Python with latest features
- **FastAPI 0.104+** - High-performance async web framework
  - Auto-generated OpenAPI documentation
  - Type hints and validation
  - Async support
  - Dependency injection

### Database & ORM
- **PostgreSQL** - Production database (relational, robust)
- **SQLite** - Development/testing database
- **SQLAlchemy 2.0** - Modern ORM with async support
- **Alembic** - Database migration tool

### API & Validation
- **Pydantic 2.5** - Data validation and settings
- **Uvicorn** - ASGI server for FastAPI
- **Python-multipart** - Form data handling

---

## AI/ML Stack

### LLM Integration
- **OpenAI API** - GPT-4 for intelligent analysis
- **Anthropic API** - Claude as alternative
- **LangChain** (optional) - LLM orchestration framework

### NLP Processing
- **spaCy 3.7** - Industry-standard NLP
  - Entity recognition
  - Text processing
  - Multilingual support
- **Transformers** (Hugging Face) - Pre-trained models
- **Sentence Transformers** - Semantic embeddings

### Vector Database (Optional)
- **ChromaDB** - Lightweight vector DB
- **Qdrant** - Production-ready vector search

---

## Data Collection Stack

### Web Scraping
- **BeautifulSoup4** - HTML parsing
- **Scrapy** - Full-featured scraping framework
- **Selenium** - JavaScript-heavy sites
- **Requests** - HTTP library

### Data Processing
- **Pandas** - Data manipulation
- **NumPy** - Numerical computing

### API Clients
- **HTTPX** - Async HTTP client
- **Requests** - Synchronous HTTP client

---

## Frontend Stack

### Core Framework
- **React 18+** - UI library
- **TypeScript** - Type safety
- **Vite** (recommended) or **Create React App**

### UI Libraries
- **Material-UI (MUI)** - Component library
  - OR **Tailwind CSS** + **shadcn/ui** - Utility-first CSS
- **React Query** - Data fetching and caching
- **Zustand** - State management (lightweight)

### Visualization
- **Recharts** - React charting library
- **Chart.js** - Alternative charting

### Form Handling
- **React Hook Form** - Form validation
- **Zod** - Schema validation (TypeScript)

---

## DevOps & Tools

### Containerization
- **Docker** - Application containerization
- **Docker Compose** - Multi-container orchestration

### Version Control
- **Git** - Source control
- **GitHub/GitLab** - Remote repository

### Development Tools
- **Black** - Code formatter
- **Flake8** - Linter
- **MyPy** - Type checking
- **Pre-commit** - Git hooks

### Testing
- **Pytest** - Python testing framework
- **Pytest-asyncio** - Async test support
- **React Testing Library** - Frontend testing

### Monitoring & Logging
- **Structlog** - Structured logging
- **Sentry** (optional) - Error tracking

---

## Security & Privacy

### Encryption
- **cryptography** - Python crypto library
- **Python-dotenv** - Environment variable management

### Compliance Tools
- **Audit logging** - Custom implementation
- **Data retention policies** - Custom implementation

---

## Deployment Options

### Backend
- **AWS/GCP/Azure** - Cloud platforms
- **Railway/Render** - Easy deployment platforms
- **Heroku** - Platform-as-a-service

### Frontend
- **Vercel** - React deployment
- **Netlify** - Static hosting
- **AWS S3 + CloudFront** - Static hosting

---

## Package Management

### Python
- **pip** - Standard package manager
- **Poetry** (optional) - Dependency management

### Node.js
- **npm** or **yarn** - Package managers

---

## API Testing

- **Postman** - API testing and documentation
- **Insomnia** - REST client
- **FastAPI Swagger UI** - Built-in API docs

---

## Recommended Development Workflow

1. **Local Development**
   - Python venv
   - SQLite database
   - FastAPI dev server
   - React dev server

2. **Testing**
   - Pytest for backend
   - React Testing Library for frontend

3. **Staging**
   - Docker Compose
   - PostgreSQL
   - Full environment variables

4. **Production**
   - Containerized deployment
   - Production database
   - Monitoring and logging

---

## Quick Install Commands

### Backend
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Frontend
```bash
cd frontend
npm install
# or
yarn install
```

---

## Why These Choices?

### FastAPI
- **Fast**: Async support for concurrent requests
- **Modern**: Type hints, Pydantic validation
- **Documentation**: Auto-generated OpenAPI/Swagger
- **Developer-friendly**: Easy to learn and use

### PostgreSQL
- **Reliable**: Production-ready, ACID compliant
- **Flexible**: JSON support, full-text search
- **Scalable**: Handles large datasets

### React + TypeScript
- **Popular**: Large ecosystem
- **Type-safe**: Catch errors early
- **Component-based**: Reusable UI components

### OpenAI/Claude APIs
- **State-of-the-art**: Best-in-class LLMs
- **API-based**: No model training needed
- **Scalable**: Pay-per-use pricing

---

## Alternative Options

If you want to explore alternatives:

- **Backend**: Flask, Django, Express.js (Node.js)
- **Database**: MongoDB, Redis (caching)
- **Frontend**: Vue.js, Svelte, Angular
- **LLM**: Local models (LLaMA, Mistral) - requires more setup

