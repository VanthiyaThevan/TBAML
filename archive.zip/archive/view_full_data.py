"""
View complete scraped data including website content
"""

import json
import sqlite3
from app.data.storage import DataStorage
from app.models.base import get_session_factory
from app.models.lob import LOBVerification

def view_full_scraped_data():
    """View all scraped data with website content"""
    
    storage = DataStorage()
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        print("="*80)
        print("COMPLETE SCRAPED COMPANY DATA")
        print("="*80)
        print()
        
        # Get all verifications with website URLs
        verifications = db.query(LOBVerification).filter(
            LOBVerification.website_source.isnot(None)
        ).order_by(LOBVerification.created_at.desc()).all()
        
        print(f"Companies with scraped content: {len(verifications)}")
        print()
        
        for i, v in enumerate(verifications, 1):
            print("="*80)
            print(f"{i}. {v.client} ({v.client_country})")
            print("="*80)
            
            print(f"\n📍 Company Information:")
            print(f"   ID: {v.id}")
            print(f"   Company: {v.client}")
            print(f"   Country: {v.client_country}")
            print(f"   Role: {v.client_role}")
            print(f"   Product: {v.product_name}")
            
            print(f"\n🌐 Website Information:")
            print(f"   URL: {v.website_source}")
            
            # Get full verification data
            full_data = storage.get_verification(v.id)
            
            print(f"\n📊 Data Collection:")
            sources = v.sources or []
            print(f"   Total Sources: {len(sources)}")
            for j, source in enumerate(sources, 1):
                if isinstance(source, dict):
                    print(f"   Source {j}: {source.get('name', 'Unknown')}")
                    print(f"      URL: {source.get('url', 'N/A')}")
                    print(f"      Collected: {source.get('collected_at', 'N/A')}")
                else:
                    print(f"   Source {j}: {source}")
            
            # Show AI response if available
            if v.ai_response:
                print(f"\n🤖 AI Analysis:")
                print(f"   {v.ai_response[:500]}...")
            
            # Show activity level and flags
            if v.activity_level:
                print(f"\n📈 Activity Level: {v.activity_level}")
            
            if v.flags:
                flags = v.flags if isinstance(v.flags, list) else json.loads(v.flags) if isinstance(v.flags, str) else []
                if flags:
                    print(f"\n⚠️  Flags/Alerts:")
                    for flag in flags[:5]:
                        print(f"   - {flag}")
            
            if v.is_red_flag:
                print(f"\n🚨 RED FLAG: {v.is_red_flag}")
            
            if v.confidence_score:
                print(f"\n💯 Confidence: {v.confidence_score}")
            
            print(f"\n⏰ Data Collection Timestamps:")
            print(f"   Created: {v.created_at}")
            if v.data_collected_at:
                print(f"   Data Collected: {v.data_collected_at}")
            if v.data_freshness_score:
                print(f"   Freshness: {v.data_freshness_score}")
            if v.last_verified_at:
                print(f"   Last Verified: {v.last_verified_at}")
            
            print()
        
        print("="*80)
        print("SUMMARY")
        print("="*80)
        
        with_url = sum(1 for v in verifications if v.website_source)
        with_sources = sum(1 for v in verifications if v.sources)
        
        print(f"Total companies with URLs: {with_url}")
        print(f"Total companies with sources: {with_sources}")
        
        # Group by country
        from collections import Counter
        countries = Counter([v.client_country for v in verifications])
        print(f"\nBy Country:")
        for country, count in countries.most_common():
            print(f"   {country}: {count}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()


def export_to_json(filename: str = "scraped_data.json"):
    """Export all scraped data to JSON file"""
    
    storage = DataStorage()
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        verifications = db.query(LOBVerification).order_by(
            LOBVerification.created_at.desc()
        ).all()
        
        export_data = []
        
        for v in verifications:
            data = {
                "id": v.id,
                "client": v.client,
                "client_country": v.client_country,
                "client_role": v.client_role,
                "product_name": v.product_name,
                "website_source": v.website_source,
                "publication_date": v.publication_date,
                "activity_level": v.activity_level,
                "flags": v.flags,
                "sources": v.sources,
                "ai_response": v.ai_response,
                "is_red_flag": v.is_red_flag,
                "confidence_score": v.confidence_score,
                "data_collected_at": v.data_collected_at.isoformat() if v.data_collected_at else None,
                "data_freshness_score": v.data_freshness_score,
                "last_verified_at": v.last_verified_at.isoformat() if v.last_verified_at else None,
                "created_at": v.created_at.isoformat() if v.created_at else None,
                "updated_at": v.updated_at.isoformat() if v.updated_at else None
            }
            export_data.append(data)
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, default=str)
        
        print(f"✅ Exported {len(export_data)} companies to {filename}")
        
    except Exception as e:
        print(f"❌ Error exporting: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--export":
        filename = sys.argv[2] if len(sys.argv) > 2 else "scraped_data.json"
        export_to_json(filename)
    else:
        view_full_scraped_data()

