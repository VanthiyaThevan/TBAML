# SEC EDGAR Data Limitations

## Important Note

The SEC EDGAR `company_tickers.json` file contains **ONLY publicly traded companies** that file reports with the SEC.

## What's Included in SEC EDGAR

- ✅ **Publicly traded companies** (stocks, bonds)
- ✅ **Companies that file periodic reports** (10-K, 10-Q, etc.)
- ✅ **Investment companies**
- ✅ **Mutual funds** (in separate files)

## What's NOT Included

- ❌ **Private companies** (unless they file with SEC)
- ❌ **LLCs, partnerships** (unless publicly traded)
- ❌ **Small businesses**
- ❌ **Companies not required to file with SEC**
- ❌ **Most privately-held corporations**

## Current File Statistics

- **File**: `company_tickers.json`
- **Companies**: ~10,142 companies
- **Type**: Publicly traded companies with SEC filings
- **Coverage**: Only US public companies filing with SEC

## Alternative Sources for Complete Company Lists

### 1. State Business Registries
- Each US state maintains business registries
- Contains ALL registered businesses (public + private)
- Examples:
  - Delaware Division of Corporations
  - California Secretary of State
  - New York Department of State
- **Access**: Varies by state (some free, some paid)

### 2. OpenCorporates
- Aggregates data from multiple sources
- Includes both public and private companies
- Global coverage (140+ jurisdictions)
- **Access**: API available (free tier + paid)

### 3. Commercial Business Databases
- **Dun & Bradstreet** (D&B)
- **Bloomberg**
- **LexisNexis**
- **ZoomInfo**
- **Access**: Mostly paid subscriptions

### 4. Other Government Sources
- **IRS Business Master File** (limited public access)
- **Census Business Register**
- **State tax registrations** (various access)

## For TBAML System

### Current Implementation
- ✅ SEC EDGAR: Covers publicly traded companies
- ❌ OpenCorporates: Available but requires API token
- ❌ State registries: Not implemented

### Recommendation
For a **complete** US company verification system, we should:

1. **Keep SEC EDGAR** for public companies (already implemented)
2. **Add OpenCorporates** integration (needs API token)
3. **Consider state registry integration** (complex - 50 states)

## What the User Asked

The user is correct - SEC EDGAR only contains a **portion** of companies (publicly traded ones).

For **comprehensive** company verification, we need multiple sources.

