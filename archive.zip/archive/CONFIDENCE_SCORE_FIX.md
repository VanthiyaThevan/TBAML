# Confidence Score and Red Flag Logic Fix

## Issue Identified

The confidence score and red flag logic were **reversed/incorrect**:

### Problem:
- **Red flags with sanctions matches** were getting **LOW confidence** ❌
- This is backwards because:
  - A sanctions match = **concrete evidence found** (HIGH confidence)
  - A red flag = **clear risk indicators found** (HIGH confidence)
  - Confidence should reflect **strength of evidence**, not whether it's positive or negative

### Root Cause:
1. `_calculate_confidence_score()` only looked at text quality/quantity, not whether we found concrete evidence
2. The refresh script didn't set confidence_score correctly for sanctions matches
3. Logic was treating "bad news" (sanctions) as "low confidence" when it should be "high confidence" (we found strong evidence)

---

## Fix Applied

### Correct Logic:
- **High Confidence** = Strong evidence found (even if negative)
  - ✅ Sanctions match = HIGH confidence (concrete evidence)
  - ✅ Red flags = HIGH confidence (clear risk indicators)
  - ✅ Multiple data sources with consistent findings = HIGH confidence

- **Low Confidence** = Limited or weak evidence
  - ✅ Limited evidence available
  - ✅ Inconsistent findings
  - ✅ Single unreliable source

### Code Changes:

1. **`app/ai/orchestrator.py`**:
   - Updated `_calculate_confidence_score()` to:
     - **First check** for sanctions matches → return "High" immediately
     - **Then check** for red flags → return "High" if red flag present
     - **Then calculate** based on evidence quality/quantity
   - Swapped order: determine red flag BEFORE calculating confidence (so confidence can use red flag info)

2. **`refresh_database_with_real_data.py`**:
   - Set `confidence_score = "High"` when sanctions match is found
   - Added logic to handle non-sanctioned cases properly

3. **`fix_confidence_scores.py`** (new script):
   - Updated all existing records in database
   - Fixed 36 records from Low/Medium/None → High confidence
   - All red flags now have HIGH confidence ✅

---

## Results

### Before Fix:
- Red flags with LOW confidence: ~36 records ❌
- Red flags with HIGH confidence: 0 records ❌

### After Fix:
- Red flags with HIGH confidence: 36 records ✅
- Red flags with LOW confidence: 0 records ✅

### Verification:
```
Total Red Flags: 36
  HIGH confidence: 36 ✅
  MEDIUM confidence: 0 ✅
  LOW confidence: 0 ✅
```

---

## Key Insight

**Confidence Score ≠ Risk Level**

- **Confidence** = How certain we are about our findings (HIGH = strong evidence, LOW = weak evidence)
- **Risk Level** = How risky the situation is (HIGH = dangerous, LOW = safe)
- **Red Flag** = Whether this is a compliance concern (True/False)

### Example:
- **Sanctions Match**:
  - Red Flag: ✅ True (this is a problem)
  - Confidence: ✅ High (we found concrete evidence)
  - Risk Level: ✅ High (sanctions are serious)

- **No Evidence Found**:
  - Red Flag: ❌ False (no clear problem)
  - Confidence: ❌ Low (we don't have enough data)
  - Risk Level: ⚠️ Unknown (can't assess without evidence)

---

## Files Modified

1. `/Users/prabhugovindan/working/hackathon/app/ai/orchestrator.py`
   - `_calculate_confidence_score()` - Updated logic
   - `analyze_lob()` - Swapped order of red flag determination and confidence calculation

2. `/Users/prabhugovindan/working/hackathon/refresh_database_with_real_data.py`
   - Added `confidence_score = "High"` for sanctions matches

3. `/Users/prabhugovindan/working/hackathon/fix_confidence_scores.py`
   - New script to fix existing database records

---

## Future Considerations

- The logic now correctly handles sanctions matches and red flags
- New AI analyses will automatically use the corrected logic
- Existing records have been fixed via the script

---

**Date Fixed**: 2025-11-01
**Status**: ✅ Complete

