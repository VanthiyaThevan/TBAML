"""
View detailed scraped content from companies
Shows the actual website content, links, and scraped data
"""

import json
from app.models.base import get_session_factory
from app.models.lob import LOBVerification


def view_scraped_content(company_name=None, limit=10):
    """
    View scraped content for companies
    
    Args:
        company_name: Optional company name to filter
        limit: Maximum number of records to show
    """
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        query = db.query(LOBVerification)
        
        if company_name:
            query = query.filter(LOBVerification.client.ilike(f"%{company_name}%"))
        
        verifications = query.order_by(
            LOBVerification.created_at.desc()
        ).limit(limit).all()
        
        print("=" * 100)
        print("DETAILED SCRAPED CONTENT FROM COMPANIES")
        print("=" * 100)
        print()
        
        for i, v in enumerate(verifications, 1):
            print(f"{'='*100}")
            print(f"COMPANY #{i}: {v.client} ({v.client_country})")
            print(f"{'='*100}\n")
            
            # Basic info
            print(f"📍 Company: {v.client}")
            print(f"🌍 Country: {v.client_country}")
            print(f"📦 Product: {v.product_name}")
            print(f"🔄 Role: {v.client_role}")
            print()
            
            # Website URL
            if v.website_source:
                print(f"🌐 Website URL: {v.website_source}")
            else:
                print("🌐 Website URL: Not found")
            print()
            
            # Data Sources
            print("📡 Data Sources:")
            if v.sources:
                sources_list = v.sources if isinstance(v.sources, list) else [v.sources]
                for j, source in enumerate(sources_list, 1):
                    if isinstance(source, dict):
                        source_name = source.get('name', 'Unknown')
                        source_url = source.get('url', 'N/A')
                        collected_at = source.get('collected_at', 'N/A')
                        print(f"  {j}. {source_name}")
                        if source_url and source_url != 'N/A':
                            print(f"     URL: {source_url}")
                        if collected_at and collected_at != 'N/A':
                            print(f"     Collected: {collected_at}")
                    else:
                        print(f"  {j}. {source}")
            else:
                print("  No sources available")
            print()
            
            # Note: The actual scraped content is stored in the aggregated data
            # which would be in a separate field. For now, we show what we have
            # stored in the database fields.
            
            # Analysis Results (if available)
            if v.activity_level:
                print(f"📊 Activity Level: {v.activity_level}")
            
            if v.ai_response:
                print(f"\n🤖 AI Analysis Response:")
                # Show first 300 chars
                ai_text = v.ai_response[:300] + "..." if len(v.ai_response) > 300 else v.ai_response
                print(f"  {ai_text}")
            
            if v.flags:
                print(f"\n⚠️  Flags:")
                if isinstance(v.flags, list):
                    for flag in v.flags:
                        print(f"  - {flag}")
                else:
                    print(f"  - {v.flags}")
            
            print(f"\n📅 Timestamps:")
            print(f"  Created: {v.created_at}")
            print(f"  Data Collected: {v.data_collected_at or 'N/A'}")
            print(f"  Freshness: {v.data_freshness_score or 'N/A'}")
            print()
            
            # Show if website was scraped
            if v.website_source:
                print("✅ Website data was collected")
                print("   (Full scraped content would be stored separately in aggregated data)")
            else:
                print("⚠️  Website URL not found - no website content scraped")
            
            print("\n" + "-" * 100 + "\n")
        
        print(f"\n{'='*100}")
        print(f"Showing {len(verifications)} records")
        print(f"{'='*100}\n")
        
    finally:
        db.close()


def export_to_json(filename="company_data.json"):
    """Export all company data to JSON file"""
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        verifications = db.query(LOBVerification).all()
        
        data = []
        for v in verifications:
            record = {
                "id": v.id,
                "company_name": v.client,
                "country": v.client_country,
                "role": v.client_role,
                "product": v.product_name,
                "website_url": v.website_source,
                "publication_date": v.publication_date,
                "activity_level": v.activity_level,
                "flags": v.flags,
                "sources": v.sources,
                "ai_response": v.ai_response,
                "is_red_flag": v.is_red_flag,
                "confidence_score": v.confidence_score,
                "data_collected_at": v.data_collected_at.isoformat() if v.data_collected_at else None,
                "data_freshness_score": v.data_freshness_score,
                "last_verified_at": v.last_verified_at.isoformat() if v.last_verified_at else None,
                "created_at": v.created_at.isoformat() if v.created_at else None,
                "updated_at": v.updated_at.isoformat() if v.updated_at else None
            }
            data.append(record)
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Exported {len(data)} records to {filename}")
        
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--export":
            filename = sys.argv[2] if len(sys.argv) > 2 else "company_data.json"
            export_to_json(filename)
        elif sys.argv[1] == "--company":
            company_name = sys.argv[2] if len(sys.argv) > 2 else None
            view_scraped_content(company_name=company_name)
        else:
            limit = int(sys.argv[1]) if sys.argv[1].isdigit() else 10
            view_scraped_content(limit=limit)
    else:
        view_scraped_content(limit=10)
