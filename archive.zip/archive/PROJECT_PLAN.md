# Trade-Based Anti-Money Laundering (TBAML) System
## UC1: Line of Business Verification - Project Plan

---

## Tech Stack Recommendation

### **Backend**
- **Language**: Python 3.11+
- **Web Framework**: FastAPI (async, auto-docs, type hints)
- **Database**: PostgreSQL (primary) + SQLite (dev/testing)
- **ORM**: SQLAlchemy 2.0
- **Cache**: Redis (optional, for rate limiting)

### **AI/ML**
- **NLP Framework**: spaCy / Transformers (Hugging Face)
- **LLM Integration**: OpenAI GPT-4 API / Anthropic Claude API
- **Vector DB**: ChromaDB / Qdrant (for semantic search)
- **Scraping**: BeautifulSoup4, Scrapy, Selenium (if needed)

### **Frontend**
- **Framework**: React 18+ with TypeScript
- **UI Library**: Material-UI / Tailwind CSS + shadcn/ui
- **State Management**: Zustand / React Query
- **Charts**: Recharts / Chart.js

### **DevOps & Tools**
- **Containerization**: Docker & Docker Compose
- **API Testing**: Postman / Insomnia
- **Version Control**: Git
- **CI/CD**: GitHub Actions (optional)
- **Environment**: Python venv / Poetry

### **Data & Privacy**
- **Encryption**: cryptography (Python library)
- **Logging**: structlog
- **Monitoring**: Sentry (optional)

---

## Stage 1: Project Setup & Infrastructure ✅

### Tasks:
- [ ] 1.1 Initialize project repository structure
- [ ] 1.2 Set up Python virtual environment
- [ ] 1.3 Install core dependencies (FastAPI, SQLAlchemy, etc.)
- [ ] 1.4 Create project directory structure
- [ ] 1.5 Set up `.env` file template for environment variables
- [ ] 1.6 Configure `.gitignore` file
- [ ] 1.7 Initialize database schema (basic tables)
- [ ] 1.8 Set up Docker configuration (if using)
- [ ] 1.9 Create README.md with project overview
- [ ] 1.10 Set up basic logging configuration

**Deliverable**: Working project skeleton with environment ready

---

## Stage 2: Data Collection & Integration ✅

### Tasks:
- [ ] 2.1 Research and document public data sources
- [ ] 2.2 Design data source connector architecture
- [ ] 2.3 Implement web scraping module (with rate limiting)
- [ ] 2.4 Create data models for LOB entities
- [ ] 2.5 Build company registry data fetcher
- [ ] 2.6 Build website content extractor
- [ ] 2.7 Build sanctions/watchlist checker (API integration)
- [ ] 2.8 Implement data validation and cleaning pipeline
- [ ] 2.9 Create data storage schema for collected data
- [ ] 2.10 Build data source attribution tracking
- [ ] 2.11 Implement error handling and retry logic
- [ ] 2.12 Add data freshness timestamp tracking

**Deliverable**: Functional data collection pipeline with multiple sources

---

## Stage 3: AI/ML Model Development ✅

### Tasks:
- [ ] 3.1 Design feature extraction pipeline
- [ ] 3.2 Build NLP text processing module
- [ ] 3.3 Implement entity extraction (company, location, activity)
- [ ] 3.4 Integrate LLM API (OpenAI/Claude) for web intelligence
- [ ] 3.5 Build activity level classifier (Active/Dormant/etc.)
- [ ] 3.6 Develop risk scoring algorithm
- [ ] 3.7 Implement flag generation logic
- [ ] 3.8 Create explainability module (feature importance)
- [ ] 3.9 Build confidence scoring mechanism
- [ ] 3.10 Design prompt templates for LLM queries
- [ ] 3.11 Implement response parsing and validation
- [ ] 3.12 Create model output format (structured response)

**Deliverable**: AI model that can analyze LOB data and generate flags

---

## Stage 4: API & Backend Development ✅

### Tasks:
- [ ] 4.1 Design API endpoint structure (RESTful)
- [ ] 4.2 Create UC1 input validation schemas (Pydantic models)
- [ ] 4.3 Implement UC1 main endpoint (`/api/v1/lob/verify`)
- [ ] 4.4 Build data aggregation service
- [ ] 4.5 Create orchestration service (calls data + AI layers)
- [ ] 4.6 Implement response formatting (UC1 output schema)
- [ ] 4.7 Add source citation to responses
- [ ] 4.8 Build database service layer (CRUD operations)
- [ ] 4.9 Implement request logging and audit trail
- [ ] 4.10 Add error handling and API error responses
- [ ] 4.11 Create health check endpoint
- [ ] 4.12 Add API rate limiting
- [ ] 4.13 Generate OpenAPI/Swagger documentation

**Deliverable**: Working REST API with UC1 endpoint

---

## Stage 5: Frontend Development ✅

### Tasks:
- [ ] 5.1 Initialize React project with TypeScript
- [ ] 5.2 Set up UI component library
- [ ] 5.3 Create UC1 input form (Client, Country, Role, Product)
- [ ] 5.4 Build API client/service for backend communication
- [ ] 5.5 Design results display component
- [ ] 5.6 Create LOB activity indicator UI
- [ ] 5.7 Build alert/flag display component (with color coding)
- [ ] 5.8 Implement source citation display
- [ ] 5.9 Add loading states and error handling
- [ ] 5.10 Create response visualization (timeline, sources)
- [ ] 5.11 Build AI response explanation view
- [ ] 5.12 Add form validation
- [ ] 5.13 Implement responsive design
- [ ] 5.14 Add basic styling/theming

**Deliverable**: Functional frontend UI for UC1

---

## Stage 6: Integration & Testing ✅

### Tasks:
- [ ] 6.1 End-to-end integration testing (frontend ↔ backend ↔ AI)
- [ ] 6.2 Test data collection pipeline with real sources
- [ ] 6.3 Test AI model with sample queries
- [ ] 6.4 Validate UC1 input/output formats
- [ ] 6.5 Test error scenarios (missing data, API failures)
- [ ] 6.6 Performance testing (response times)
- [ ] 6.7 Test flag generation accuracy
- [ ] 6.8 Validate source attribution
- [ ] 6.9 Test privacy controls (no data leakage)
- [ ] 6.10 Cross-browser testing (frontend)
- [ ] 6.11 Load testing (if applicable)
- [ ] 6.12 Fix identified bugs

**Deliverable**: Fully integrated and tested system

---

## Stage 7: Compliance & Documentation ✅

### Tasks:
- [ ] 7.1 Document data sources and collection methods
- [ ] 7.2 Create decision logic documentation
- [ ] 7.3 Document risk scoring methodology
- [ ] 7.4 Write API documentation
- [ ] 7.5 Create user guide/documentation
- [ ] 7.6 Document privacy controls implemented
- [ ] 7.7 Create data flow diagrams
- [ ] 7.8 Write deployment guide
- [ ] 7.9 Document model assumptions and limitations
- [ ] 7.10 Create compliance checklist
- [ ] 7.11 Add code comments and docstrings
- [ ] 7.12 Prepare demo/presentation materials

**Deliverable**: Complete documentation and compliance-ready system

---

## Verification Checklist

Use this checklist after each stage to verify completion:

### Stage 1 Verification:
- ✅ Can run project locally
- ✅ Dependencies installed
- ✅ Database connection working
- ✅ Basic project structure in place

### Stage 2 Verification:
- ✅ Can collect data from at least 2 sources
- ✅ Data stored in database
- ✅ Source attribution tracked
- ✅ Error handling works

### Stage 3 Verification:
- ✅ Can process text and extract entities
- ✅ LLM integration working
- ✅ Can classify activity level
- ✅ Can generate flags
- ✅ Response includes explanation

### Stage 4 Verification:
- ✅ API endpoint accepts UC1 inputs
- ✅ Returns UC1 outputs
- ✅ Source citations included
- ✅ API documentation accessible
- ✅ Error handling works

### Stage 5 Verification:
- ✅ Form accepts all UC1 inputs
- ✅ Results display correctly
- ✅ Flags/alerts visible
- ✅ Sources shown
- ✅ UI responsive

### Stage 6 Verification:
- ✅ End-to-end flow works
- ✅ No critical bugs
- ✅ Performance acceptable
- ✅ Error scenarios handled

### Stage 7 Verification:
- ✅ All documentation complete
- ✅ Code documented
- ✅ Demo ready
- ✅ Compliance considerations addressed

---

## Success Criteria

### Minimum Viable Product (MVP):
- Accepts UC1 inputs (Client, Country, Role, Product)
- Collects data from at least 2 public sources
- Uses AI to analyze LOB
- Generates flags/alerts
- Shows activity level
- Provides source citations

### Enhanced Version:
- Multiple data sources (5+)
- Advanced AI analysis
- Risk scoring
- Explainable AI responses
- Full compliance documentation
- Production-ready code

---

## Timeline Suggestion (for Hackathon)

- **Stage 1**: 1-2 hours
- **Stage 2**: 3-4 hours
- **Stage 3**: 4-5 hours
- **Stage 4**: 3-4 hours
- **Stage 5**: 4-5 hours
- **Stage 6**: 2-3 hours
- **Stage 7**: 2-3 hours

**Total**: ~20-26 hours (can be parallelized)

