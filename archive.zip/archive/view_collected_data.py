"""
View collected company data from database
"""

from app.data.storage import DataStorage
from app.models.base import get_session_factory
from app.models.lob import LOBVerification

storage = DataStorage()
SessionLocal, _ = get_session_factory()
db = SessionLocal()

print("="*60)
print("Collected Company Data Summary")
print("="*60)
print()

# Get all verifications
verifications = db.query(LOBVerification).order_by(LOBVerification.created_at.desc()).all()

print(f"Total companies in database: {len(verifications)}")
print()

# Filter for the companies we just tested
target_companies = [
    "Vitol Group", "Trafigura Group", "Glencore", "Gunvor Group",
    "Mercuria Energy Group", "Koch Industries", "ExxonMobil",
    "Shell plc", "BP (British Petroleum)", "TotalEnergies",
    "Chevron", "Eni", "ConocoPhillips", "Rosneft Oil Company",
    "Lukoil OAO", "Gazprom Neft", "Surgutneftegas"
]

recent_verifications = [
    v for v in verifications 
    if any(target.lower() in v.client.lower() for target in target_companies)
]

print(f"Target companies found: {len(recent_verifications)}")
print()

for i, v in enumerate(recent_verifications, 1):
    print(f"{i}. {v.client} ({v.client_country})")
    print(f"   Role: {v.client_role}, Product: {v.product_name}")
    print(f"   URL: {v.website_source or 'Not found'}")
    print(f"   Sources: {len(v.sources) if v.sources else 0} data sources")
    print(f"   Created: {v.created_at}")
    if v.data_collected_at:
        print(f"   Data collected: {v.data_collected_at}")
    if v.data_freshness_score:
        print(f"   Freshness: {v.data_freshness_score}")
    print()

db.close()

print("="*60)
print(f"Total stored: {len(recent_verifications)}/{len(target_companies)} companies")
print("="*60)

