"""
Fix Confidence Scores in Database
Corrects confidence scores based on the logic:
- Sanctions match = HIGH confidence (concrete evidence found)
- Red flags = HIGH confidence (clear risk indicators found)
- Limited evidence = LOW confidence (but sanctions match overrides this)
"""

from app.models.base import get_session_factory
from app.models.lob import LOBVerification
from app.core.logging import get_logger

logger = get_logger(__name__)


def fix_confidence_scores():
    """Fix confidence scores for all verification records"""
    
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        # Get all verification records
        verifications = db.query(LOBVerification).all()
        
        print("=" * 80)
        print("Fixing Confidence Scores")
        print("=" * 80)
        print(f"\nFound {len(verifications)} verification records to check\n")
        
        updated_count = 0
        skipped_count = 0
        
        for i, verification in enumerate(verifications, 1):
            try:
                needs_update = False
                new_confidence = None
                
                # Get flags
                flags = verification.flags or []
                if isinstance(flags, str):
                    # Try to parse as JSON if it's a string
                    import json
                    try:
                        flags = json.loads(flags)
                    except:
                        flags = [flags]
                
                # Check for sanctions match
                has_sanctions_match = False
                if flags:
                    flags_str = str(flags).lower()
                    if "sanctions_match" in flags_str and "high" in flags_str:
                        has_sanctions_match = True
                
                # Apply correction logic
                if verification.is_red_flag:
                    # Red flags should have HIGH confidence (we found clear evidence)
                    if verification.confidence_score != "High":
                        new_confidence = "High"
                        needs_update = True
                        reason = "Red flag - clear evidence found"
                elif has_sanctions_match:
                    # Sanctions match should have HIGH confidence (concrete evidence)
                    if verification.confidence_score != "High":
                        new_confidence = "High"
                        needs_update = True
                        reason = "Sanctions match - concrete evidence"
                else:
                    # No red flags or sanctions - check current confidence
                    # If it was set to "High" without evidence, it might be wrong
                    # But we'll only update if it's clearly wrong
                    if verification.confidence_score == "High" and not verification.ai_response:
                        # High confidence without AI analysis or evidence is suspicious
                        new_confidence = "Low"
                        needs_update = True
                        reason = "High confidence without evidence - adjusting"
                
                if needs_update:
                    old_confidence = verification.confidence_score
                    verification.confidence_score = new_confidence
                    db.commit()
                    
                    updated_count += 1
                    print(f"[{i}/{len(verifications)}] ✅ Updated: {verification.client}")
                    print(f"  Old: {old_confidence} → New: {new_confidence} ({reason})")
                    
                    if has_sanctions_match:
                        print(f"  ⚠️  Has sanctions match")
                    if verification.is_red_flag:
                        print(f"  🚩 Is red flag")
                else:
                    skipped_count += 1
                    if i <= 10:  # Show first 10 skipped for debugging
                        print(f"[{i}/{len(verifications)}] ⏭️  Skipped: {verification.client} (confidence: {verification.confidence_score})")
            
            except Exception as e:
                logger.error(f"Error fixing verification {verification.id}: {str(e)}", exc_info=True)
                print(f"  ❌ Error: {str(e)[:100]}")
                db.rollback()
        
        print("\n" + "=" * 80)
        print("Fix Complete!")
        print("=" * 80)
        print(f"✅ Updated: {updated_count} records")
        print(f"⏭️  Skipped: {skipped_count} records")
        print(f"📊 Total: {len(verifications)} records")
        
        # Show summary
        db.refresh(verifications[0]) if verifications else None
        red_flags_high_confidence = db.query(LOBVerification).filter(
            LOBVerification.is_red_flag == True,
            LOBVerification.confidence_score == "High"
        ).count()
        
        red_flags_low_confidence = db.query(LOBVerification).filter(
            LOBVerification.is_red_flag == True,
            LOBVerification.confidence_score == "Low"
        ).count()
        
        print(f"\n📈 Summary:")
        print(f"  Red flags with HIGH confidence: {red_flags_high_confidence}")
        print(f"  Red flags with LOW confidence: {red_flags_low_confidence}")
        if red_flags_low_confidence > 0:
            print(f"  ⚠️  Warning: {red_flags_low_confidence} red flags still have LOW confidence")
        
    except Exception as e:
        logger.error(f"Error fixing confidence scores: {str(e)}", exc_info=True)
        print(f"\n❌ Fatal error: {str(e)}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("Confidence Score Fix Script")
    print("=" * 80)
    print("\nThis script will fix confidence scores based on:")
    print("  ✅ Sanctions match = HIGH confidence (concrete evidence)")
    print("  ✅ Red flags = HIGH confidence (clear risk indicators)")
    print("  ✅ Limited evidence = LOW confidence")
    print("\n" + "=" * 80)
    print()
    
    fix_confidence_scores()

