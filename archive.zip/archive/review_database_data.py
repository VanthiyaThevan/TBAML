"""
Review Database Data
Comprehensive review of all data stored in SQLite after validations
"""

import json
from datetime import datetime
from app.models.base import get_session_factory
from app.models.lob import LOBVerification


def format_timestamp(ts):
    """Format timestamp for display"""
    if ts:
        if isinstance(ts, str):
            return ts
        return ts.strftime("%Y-%m-%d %H:%M:%S")
    return "N/A"


def review_all_data():
    """Review all data in database"""
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        verifications = db.query(LOBVerification).order_by(
            LOBVerification.id.desc()
        ).all()
        
        print("=" * 100)
        print("DATABASE DATA REVIEW - AFTER STAGE 3 VALIDATIONS")
        print("=" * 100)
        print(f"\nTotal Records: {len(verifications)}\n")
        
        # Summary Statistics
        print("-" * 100)
        print("SUMMARY STATISTICS")
        print("-" * 100)
        print()
        
        with_ai_response = sum(1 for v in verifications if v.ai_response)
        with_activity = sum(1 for v in verifications if v.activity_level and v.activity_level != "Unknown")
        with_flags = sum(1 for v in verifications if v.flags and 
                        (isinstance(v.flags, list) and len(v.flags) > 0 or 
                         isinstance(v.flags, str) and v.flags.strip()))
        with_website = sum(1 for v in verifications if v.website_source)
        with_pub_date = sum(1 for v in verifications if v.publication_date)
        with_sources = sum(1 for v in verifications if v.sources)
        red_flags = sum(1 for v in verifications if v.is_red_flag)
        with_confidence = sum(1 for v in verifications if v.confidence_score)
        
        print(f"Total Records: {len(verifications)}")
        print(f"With AI Response: {with_ai_response}/{len(verifications)} ({with_ai_response/len(verifications)*100:.1f}%)")
        print(f"With Activity Level: {with_activity}/{len(verifications)} ({with_activity/len(verifications)*100:.1f}%)")
        print(f"With Flags: {with_flags}/{len(verifications)} ({with_flags/len(verifications)*100:.1f}%)")
        print(f"With Website URL: {with_website}/{len(verifications)} ({with_website/len(verifications)*100:.1f}%)")
        print(f"With Publication Date: {with_pub_date}/{len(verifications)} ({with_pub_date/len(verifications)*100:.1f}%)")
        print(f"With Sources: {with_sources}/{len(verifications)} ({with_sources/len(verifications)*100:.1f}%)")
        print(f"Red Flags: {red_flags}/{len(verifications)} ({red_flags/len(verifications)*100:.1f}%)")
        print(f"With Confidence Score: {with_confidence}/{len(verifications)} ({with_confidence/len(verifications)*100:.1f}%)")
        print()
        
        # UC1 Output Completeness
        print("-" * 100)
        print("UC1 OUTPUT COMPLETENESS")
        print("-" * 100)
        print()
        
        uc1_complete = 0
        for v in verifications:
            complete = all([
                v.ai_response,
                v.activity_level and v.activity_level != "Unknown",
                v.flags and (isinstance(v.flags, list) and len(v.flags) > 0 or isinstance(v.flags, str) and v.flags.strip()),
                v.publication_date or v.website_source,
                v.sources
            ])
            if complete:
                uc1_complete += 1
        
        print(f"UC1 Complete Records: {uc1_complete}/{len(verifications)} ({uc1_complete/len(verifications)*100:.1f}%)")
        print()
        
        # Activity Level Distribution
        print("-" * 100)
        print("ACTIVITY LEVEL DISTRIBUTION")
        print("-" * 100)
        print()
        
        activity_dist = {}
        for v in verifications:
            level = v.activity_level or "Not Set"
            activity_dist[level] = activity_dist.get(level, 0) + 1
        
        for level, count in sorted(activity_dist.items(), key=lambda x: x[1], reverse=True):
            print(f"  {level}: {count} ({count/len(verifications)*100:.1f}%)")
        print()
        
        # Confidence Score Distribution
        print("-" * 100)
        print("CONFIDENCE SCORE DISTRIBUTION")
        print("-" * 100)
        print()
        
        confidence_dist = {}
        for v in verifications:
            score = v.confidence_score or "Not Set"
            confidence_dist[score] = confidence_dist.get(score, 0) + 1
        
        for score, count in sorted(confidence_dist.items(), key=lambda x: x[1], reverse=True):
            print(f"  {score}: {count} ({count/len(verifications)*100:.1f}%)")
        print()
        
        # Countries Distribution
        print("-" * 100)
        print("COUNTRIES DISTRIBUTION")
        print("-" * 100)
        print()
        
        country_dist = {}
        for v in verifications:
            country = v.client_country or "Unknown"
            country_dist[country] = country_dist.get(country, 0) + 1
        
        for country, count in sorted(country_dist.items(), key=lambda x: x[1], reverse=True):
            print(f"  {country}: {count}")
        print()
        
        # Recent Records (Last 10)
        print("=" * 100)
        print("RECENT RECORDS (Last 10)")
        print("=" * 100)
        print()
        
        for i, v in enumerate(verifications[:10], 1):
            print(f"{'='*100}")
            print(f"RECORD #{i} - ID: {v.id}")
            print(f"{'='*100}\n")
            
            # Basic Info
            print("📋 COMPANY INFORMATION:")
            print(f"  Name: {v.client}")
            print(f"  Country: {v.client_country}")
            print(f"  Role: {v.client_role}")
            print(f"  Product: {v.product_name}")
            print()
            
            # UC1 Outputs
            print("📊 UC1 OUTPUTS:")
            
            if v.ai_response:
                print(f"  ✅ AI Response: Present ({len(v.ai_response)} chars)")
                print(f"     Preview: {v.ai_response[:200]}...")
            else:
                print(f"  ❌ AI Response: Missing")
            
            if v.activity_level:
                print(f"  ✅ Activity Level: {v.activity_level}")
            else:
                print(f"  ❌ Activity Level: Not set")
            
            if v.flags:
                flags_list = v.flags if isinstance(v.flags, list) else [v.flags]
                if isinstance(flags_list, list) and len(flags_list) > 0 and flags_list[0]:
                    print(f"  ✅ Flags: {len(flags_list)} flag(s)")
                    for flag in flags_list[:3]:
                        print(f"     - {flag}")
                else:
                    print(f"  ⚠️  Flags: Field exists but empty")
            else:
                print(f"  ❌ Flags: Not set")
            
            if v.website_source:
                print(f"  ✅ Website Source: {v.website_source}")
            else:
                print(f"  ❌ Website Source: Not found")
            
            if v.publication_date:
                print(f"  ✅ Publication Date: {v.publication_date}")
            else:
                print(f"  ❌ Publication Date: Not extracted")
            
            if v.sources:
                sources_list = v.sources if isinstance(v.sources, list) else [v.sources]
                print(f"  ✅ Sources: {len(sources_list)} source(s)")
                for j, source in enumerate(sources_list[:3], 1):
                    if isinstance(source, dict):
                        print(f"     {j}. {source.get('name', 'Unknown')}")
                    else:
                        print(f"     {j}. {source}")
            else:
                print(f"  ❌ Sources: Not tracked")
            
            print()
            
            # Additional Info
            print("📈 ADDITIONAL INFO:")
            print(f"  Confidence Score: {v.confidence_score or 'Not set'}")
            print(f"  Red Flag: {'Yes ⚠️' if v.is_red_flag else 'No'}")
            print(f"  Created: {format_timestamp(v.created_at)}")
            print(f"  Updated: {format_timestamp(v.updated_at)}")
            if v.data_collected_at:
                print(f"  Data Collected: {format_timestamp(v.data_collected_at)}")
            if v.last_verified_at:
                print(f"  Last Verified: {format_timestamp(v.last_verified_at)}")
            if v.data_freshness_score:
                print(f"  Freshness: {v.data_freshness_score}")
            print()
        
        # Records with AI Analysis
        print("=" * 100)
        print("RECORDS WITH AI ANALYSIS")
        print("=" * 100)
        print()
        
        ai_records = [v for v in verifications if v.ai_response]
        
        if ai_records:
            print(f"Found {len(ai_records)} records with AI analysis:\n")
            for v in ai_records[:10]:
                print(f"  ID {v.id}: {v.client}")
                print(f"    Activity: {v.activity_level or 'N/A'}")
                print(f"    Flags: {len(v.flags) if isinstance(v.flags, list) else '0'} flags")
                print(f"    Red Flag: {'Yes' if v.is_red_flag else 'No'}")
                print()
        else:
            print("No records found with AI analysis.")
            print()
        
        print("=" * 100)
        
    finally:
        db.close()


def export_to_json(filename="database_review.json"):
    """Export database review to JSON"""
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        verifications = db.query(LOBVerification).all()
        
        data = {
            "review_date": datetime.now().isoformat(),
            "total_records": len(verifications),
            "statistics": {},
            "records": []
        }
        
        # Calculate statistics
        data["statistics"] = {
            "with_ai_response": sum(1 for v in verifications if v.ai_response),
            "with_activity_level": sum(1 for v in verifications if v.activity_level and v.activity_level != "Unknown"),
            "with_flags": sum(1 for v in verifications if v.flags and 
                            (isinstance(v.flags, list) and len(v.flags) > 0 or 
                             isinstance(v.flags, str) and v.flags.strip())),
            "with_website": sum(1 for v in verifications if v.website_source),
            "with_publication_date": sum(1 for v in verifications if v.publication_date),
            "with_sources": sum(1 for v in verifications if v.sources),
            "red_flags": sum(1 for v in verifications if v.is_red_flag),
            "with_confidence_score": sum(1 for v in verifications if v.confidence_score)
        }
        
        # Export records
        for v in verifications:
            record = {
                "id": v.id,
                "company_name": v.client,
                "country": v.client_country,
                "role": v.client_role,
                "product": v.product_name,
                "ai_response": v.ai_response,
                "activity_level": v.activity_level,
                "flags": v.flags,
                "website_source": v.website_source,
                "publication_date": v.publication_date,
                "sources": v.sources,
                "confidence_score": v.confidence_score,
                "is_red_flag": v.is_red_flag,
                "created_at": v.created_at.isoformat() if v.created_at else None,
                "updated_at": v.updated_at.isoformat() if v.updated_at else None,
                "data_collected_at": v.data_collected_at.isoformat() if v.data_collected_at else None,
                "last_verified_at": v.last_verified_at.isoformat() if v.last_verified_at else None,
                "data_freshness_score": v.data_freshness_score
            }
            data["records"].append(record)
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Data exported to: {filename}")
        
    finally:
        db.close()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--export":
        export_to_json()
    else:
        review_all_data()

