"""
Check UC1 Output Field Completeness
Verifies if all required UC1 outputs are present
"""

from app.models.base import get_session_factory
from app.models.lob import LOBVerification
from collections import defaultdict


def check_uc1_outputs():
    """Check UC1 output field completeness"""
    SessionLocal, _ = get_session_factory()
    db = SessionLocal()
    
    try:
        verifications = db.query(LOBVerification).all()
        
        print("=" * 80)
        print("UC1 OUTPUT FIELD COMPLETENESS CHECK")
        print("=" * 80)
        print()
        
        print("UC1 Required Output Fields (from specification):")
        print("1. AI Response")
        print("2. Website source / Date of info Publication")
        print("3. Activity level of LOB (Active, Dormant, etc.)")
        print("4. Alerts or Flags (e.g., compliance issues, risk warnings)")
        print("5. Source citation")
        print()
        
        print("-" * 80)
        print("CURRENT STATUS:")
        print("-" * 80)
        print()
        
        # Check each field
        stats = {
            "total": len(verifications),
            "ai_response": 0,
            "website_source": 0,
            "publication_date": 0,
            "activity_level": 0,
            "flags": 0,
            "sources": 0,
            "meaningful_flags": 0  # Flags that aren't just empty/null
        }
        
        for v in verifications:
            if v.ai_response:
                stats["ai_response"] += 1
            if v.website_source:
                stats["website_source"] += 1
            if v.publication_date:
                stats["publication_date"] += 1
            if v.activity_level:
                stats["activity_level"] += 1
            if v.flags:
                stats["flags"] += 1
                # Check if flags are meaningful (not just empty list/null)
                if isinstance(v.flags, list) and len(v.flags) > 0:
                    stats["meaningful_flags"] += 1
                elif isinstance(v.flags, str) and v.flags.strip():
                    stats["meaningful_flags"] += 1
            if v.sources:
                stats["sources"] += 1
        
        # Field 1: AI Response
        print(f"1. AI Response:")
        print(f"   ✅ Field exists: Yes")
        print(f"   📊 Populated: {stats['ai_response']}/{stats['total']} ({stats['ai_response']/stats['total']*100:.1f}%)")
        print(f"   ❌ STATUS: MISSING - Requires Stage 3 (AI/ML Model Development)")
        print()
        
        # Field 2: Website source / Publication Date
        print(f"2. Website source / Date of info Publication:")
        print(f"   Website: {stats['website_source']}/{stats['total']} ({stats['website_source']/stats['total']*100:.1f}%)")
        print(f"   Publication Date: {stats['publication_date']}/{stats['total']} ({stats['publication_date']/stats['total']*100:.1f}%)")
        if stats['publication_date'] < stats['total']:
            print(f"   ⚠️  Publication date not extracted from scraped content")
        print()
        
        # Field 3: Activity Level
        print(f"3. Activity level of LOB:")
        print(f"   ✅ Field exists: Yes")
        print(f"   📊 Populated: {stats['activity_level']}/{stats['total']} ({stats['activity_level']/stats['total']*100:.1f}%)")
        print(f"   ❌ STATUS: MISSING - Requires Stage 3 (AI/ML Model Development)")
        print()
        
        # Field 4: Flags/Alerts
        print(f"4. Alerts or Flags:")
        print(f"   ✅ Field exists: Yes")
        print(f"   📊 Populated: {stats['flags']}/{stats['total']} ({stats['flags']/stats['total']*100:.1f}%)")
        print(f"   📊 Meaningful flags: {stats['meaningful_flags']}/{stats['total']}")
        if stats['meaningful_flags'] < stats['total']:
            print(f"   ❌ STATUS: MISSING - Requires Stage 3 (AI/ML to generate flags)")
        print()
        
        # Field 5: Sources
        print(f"5. Source citation:")
        print(f"   ✅ Field exists: Yes")
        print(f"   📊 Populated: {stats['sources']}/{stats['total']} ({stats['sources']/stats['total']*100:.1f}%)")
        print(f"   ✅ STATUS: COMPLETE")
        print()
        
        print("=" * 80)
        print("SUMMARY")
        print("=" * 80)
        print()
        
        completed_fields = 0
        total_fields = 5
        
        if stats['ai_response'] == stats['total']:
            completed_fields += 1
            print("✅ AI Response: COMPLETE")
        else:
            print("❌ AI Response: MISSING")
        
        if stats['website_source'] == stats['total'] and stats['publication_date'] == stats['total']:
            completed_fields += 1
            print("✅ Website source / Publication Date: COMPLETE")
        elif stats['website_source'] == stats['total']:
            print("⚠️  Website source / Publication Date: PARTIAL (missing publication dates)")
        else:
            print("❌ Website source / Publication Date: INCOMPLETE")
        
        if stats['activity_level'] == stats['total']:
            completed_fields += 1
            print("✅ Activity Level: COMPLETE")
        else:
            print("❌ Activity Level: MISSING")
        
        if stats['meaningful_flags'] == stats['total']:
            completed_fields += 1
            print("✅ Flags/Alerts: COMPLETE")
        else:
            print("❌ Flags/Alerts: MISSING")
        
        if stats['sources'] == stats['total']:
            completed_fields += 1
            print("✅ Source citation: COMPLETE")
        else:
            print("❌ Source citation: MISSING")
        
        print()
        print(f"Completion: {completed_fields}/{total_fields} fields complete")
        print()
        
        if completed_fields < total_fields:
            print("⚠️  UC1 OUTPUTS ARE INCOMPLETE")
            print()
            print("Missing Components:")
            print("- AI Response: Needs Stage 3 (AI/ML Model)")
            print("- Activity Level: Needs Stage 3 (AI/ML Model)")
            print("- Flags/Alerts: Needs Stage 3 (AI/ML Model)")
            print("- Publication Date: Could extract from scraped content")
            print()
            print("Current Stage: Stage 2 Complete (Data Collection)")
            print("Next Stage: Stage 3 (AI/ML Model Development)")
        else:
            print("✅ All UC1 outputs complete!")
        
        print("=" * 80)
        
    finally:
        db.close()


if __name__ == "__main__":
    check_uc1_outputs()

